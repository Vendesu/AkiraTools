from telethon import TelegramClient
import asyncio
import csv
import json

def load_credentials():
    try:
        with open('credentials.json', 'r') as f:
            credentials = json.load(f)
        return credentials['api_id'], credentials['api_hash']
    except FileNotFoundError:
        return None, None

async def main():
    api_id, api_hash = load_credentials()
    if not api_id or not api_hash:
        print("Kredensial tidak ditemukan. Jalankan login.py terlebih dahulu.")
        return

    client = TelegramClient('session', api_id, api_hash)
    await client.start()

    message = input("Masukkan pesan yang ingin dikirim ke semua anggota: ")

    with open('user_id.csv', 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                await client.send_message(int(row['User ID']), message)
                print(f"Pesan terkirim ke: {row['First Name']} {row['Last Name']}")
            except Exception as e:
                print(f"Gagal mengirim pesan ke {row['First Name']} {row['Last Name']}: {str(e)}")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())