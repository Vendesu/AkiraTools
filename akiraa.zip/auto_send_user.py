from telethon import TelegramClient
import asyncio
import csv
import json
import os

ACCOUNTS_FILE = 'telegram_accounts.json'

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

async def main():
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.")
        return

    print("Pilih akun yang akan digunakan:")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = int(input("Masukkan nomor akun: "))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    api_id = account['api_id']
    api_hash = account['api_hash']
    phone_number = account['phone_number']

    client = TelegramClient(f'session_{account_name}', api_id, api_hash)
    await client.start(phone=phone_number)

    message = input("Masukkan pesan yang ingin dikirim ke semua anggota: ")

    with open('user_id.csv', 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                await client.send_message(int(row['User ID']), message)
                print(f"Pesan terkirim ke: {row['First Name']} {row['Last Name']}")
            except Exception as e:
                print(f"Gagal mengirim pesan ke {row['First Name']} {row['Last Name']}: {str(e)}")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())