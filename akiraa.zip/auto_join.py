from telethon import TelegramClient
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
import asyncio
import csv
import os

async def add_to_csv(filename, data):
    mode = 'a' if os.path.exists(filename) else 'w'
    with open(filename, mode, newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if mode == 'w':
            if filename == 'grup_id.csv':
                writer.writerow(['Group ID', 'Group Name'])
            else:
                writer.writerow(['User ID', 'First Name', 'Last Name', 'Username'])
        writer.writerow(data)

async def join_group(client, link):
    try:
        if 'joinchat' in link:
            invite_hash = link.split('/')[-1]
            updates = await client(ImportChatInviteRequest(invite_hash))
            chat = updates.chats[0]
        else:
            username = link.split('/')[-1]
            chat = await client(JoinChannelRequest(username))
        
        print(f"Berhasil bergabung dengan grup: {chat.title}")
        return chat
    except Exception as e:
        print(f"Gagal bergabung dengan grup: {str(e)}")
        return None

async def get_members(client, chat):
    members = []
    async for user in client.iter_participants(chat):
        members.append((user.id, user.first_name, user.last_name, user.username))
    return members

async def main():
    # Menggunakan session yang sudah ada
    client = TelegramClient('session', None, None)
    await client.start()

    while True:
        link = input("Masukkan link grup (atau 'q' untuk keluar): ")
        if link.lower() == 'q':
            break

        chat = await join_group(client, link)
        if chat:
            # Tambahkan grup ke grup_id.csv
            await add_to_csv('grup_id.csv', [chat.id, chat.title])

            # Dapatkan dan tambahkan anggota ke user_id.csv
            members = await get_members(client, chat)
            for member in members:
                await add_to_csv('user_id.csv', member)

            print(f"Berhasil menambahkan {len(members)} anggota ke database.")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())