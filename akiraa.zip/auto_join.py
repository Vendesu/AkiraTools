from telethon import TelegramClient
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
import asyncio
import csv
import os
import json

ACCOUNTS_FILE = 'telegram_accounts.json'

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

async def add_to_csv(filename, data):
    mode = 'a' if os.path.exists(filename) else 'w'
    with open(filename, mode, newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if mode == 'w':
            if filename == 'grup_id.csv':
                writer.writerow(['Group ID', 'Group Name'])
            else:
                writer.writerow(['User ID', 'First Name', 'Last Name', 'Username'])
        writer.writerow(data)

async def add_group_username(username):
    with open('grup_username.csv', 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([username])

async def join_group(client, link):
    try:
        if 'joinchat' in link:
            invite_hash = link.split('/')[-1]
            result = await client(ImportChatInviteRequest(invite_hash))
            if hasattr(result, 'chats') and result.chats:
                chat = result.chats[0]
            else:
                chat = result.chat
        else:
            username = link.split('/')[-1]
            result = await client(JoinChannelRequest(username))
            chat = result.chats[0] if hasattr(result, 'chats') else result.chat
        
        chat_title = getattr(chat, 'title', 'Unknown Group')
        print(f"Berhasil bergabung dengan grup: {chat_title}")
        return chat
    except Exception as e:
        print(f"Gagal bergabung dengan grup: {str(e)}")
        return None

async def get_members(client, chat):
    members = []
    async for user in client.iter_participants(chat):
        members.append((user.id, user.first_name, user.last_name, user.username))
    return members

async def main():
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.")
        return

    print("Pilih akun yang akan digunakan:")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = int(input("Masukkan nomor akun: "))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    api_id = account['api_id']
    api_hash = account['api_hash']
    phone_number = account['phone_number']

    client = TelegramClient(f'session_{account_name}', api_id, api_hash)
    await client.start(phone=phone_number)

    while True:
        link = input("Masukkan link/username grup (atau 'q' untuk keluar): ")
        if link.lower() == 'q':
            break

        username = link.split('/')[-1]
        chat = await join_group(client, link)
        if chat:
            # Tambahkan grup ke grup_id.csv
            chat_title = getattr(chat, 'title', 'Unknown Group')
            await add_to_csv('grup_id.csv', [chat.id, chat_title])

            # Simpan username grup
            await add_group_username(username)

            # Dapatkan dan tambahkan anggota ke user_id.csv
            members = await get_members(client, chat)
            for member in members:
                await add_to_csv('user_id.csv', member)

            print(f"Berhasil menambahkan {len(members)} anggota ke database.")

    # Tambahkan opsi untuk bergabung dengan semua grup dari grup_username.csv
    join_all = input("Apakah Anda ingin bergabung dengan semua grup dari grup_username.csv? (y/n): ")
    if join_all.lower() == 'y':
        with open('grup_username.csv', 'r', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            for row in reader:
                username = row[0]
                chat = await join_group(client, f"https://t.me/{username}")
                if chat:
                    print(f"Berhasil bergabung dengan grup: {username}")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())
