from telethon import TelegramClient
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.types import Channel, Chat
from telethon.errors import UsernameInvalidError, UsernameNotOccupiedError
import asyncio
import csv
import os
import json
import re

ACCOUNTS_FILE = 'telegram_accounts.json'
SCRAPE_FILE = 'scrape_grup.csv'

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    YELLOW = '\033[93m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color):
    width = 60
    print(color + "╔" + "═" * (width - 2) + "╗")
    print("║" + text.center(width - 2) + "║")
    print("╚" + "═" * (width - 2) + "╝" + Colors.ENDC)

def print_left_aligned_box(title, options, color):
    width = 60
    print(color + "╔" + "═" * (width - 2) + "╗")
    print("║" + title.center(width - 2) + "║")
    print("╠" + "═" * (width - 2) + "╣")
    for option in options:
        print("║ " + option.ljust(width - 3) + "║")
    print("╚" + "═" * (width - 2) + "╝" + Colors.ENDC)

def get_user_choice(max_choice):
    while True:
        try:
            choice = int(input(f"{Colors.CYAN}Pilih menu (0-{max_choice}): {Colors.ENDC}"))
            if 0 <= choice <= max_choice:
                return choice
            else:
                print(f"{Colors.FAIL}Pilihan tidak valid. Silakan coba lagi.{Colors.ENDC}")
        except ValueError:
            print(f"{Colors.FAIL}Masukkan angka yang valid.{Colors.ENDC}")

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def ensure_scrape_file_exists():
    if not os.path.exists(SCRAPE_FILE):
        with open(SCRAPE_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['username', 'group_name'])  # Write header

async def add_group_username(username, group_name):
    with open(SCRAPE_FILE, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([username, group_name])

async def is_valid_group(client, username):
    try:
        entity = await client.get_entity(username)
        if isinstance(entity, (Channel, Chat)):
            return entity.megagroup or isinstance(entity, Chat)
        return False
    except UsernameInvalidError:
        print(f"{Colors.FAIL}Username tidak valid: {username}{Colors.ENDC}")
    except UsernameNotOccupiedError:
        print(f"{Colors.FAIL}Username tidak terdaftar: {username}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Terjadi kesalahan saat memeriksa username {username}: {str(e)}{Colors.ENDC}")
    return False

async def validate_and_add_group_username(client, username):
    try:
        entity = await client.get_entity(username)
        if isinstance(entity, (Channel, Chat)):
            if entity.megagroup or isinstance(entity, Chat):
                await add_group_username(username, entity.title)
                print(f"{Colors.GREEN}Username {username} adalah grup yang valid dan telah disimpan.{Colors.ENDC}")
                return True
            else:
                print(f"{Colors.WARNING}Username {username} adalah channel, bukan grup. Tidak disimpan.{Colors.ENDC}")
                return False
        else:
            print(f"{Colors.WARNING}Username {username} bukan merupakan grup atau channel. Tidak disimpan.{Colors.ENDC}")
            return False
    except UsernameInvalidError:
        print(f"{Colors.FAIL}Username tidak valid: {username}{Colors.ENDC}")
    except UsernameNotOccupiedError:
        print(f"{Colors.FAIL}Username tidak terdaftar: {username}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Terjadi kesalahan saat memeriksa username {username}: {str(e)}{Colors.ENDC}")
    return False

async def join_group(client, link):
    try:
        if 'joinchat' in link:
            invite_hash = link.split('/')[-1]
            result = await client(ImportChatInviteRequest(invite_hash))
            if hasattr(result, 'chats') and result.chats:
                chat = result.chats[0]
            else:
                chat = result.chat
        else:
            username = link.split('/')[-1]
            if not await is_valid_group(client, username):
                return None
            result = await client(JoinChannelRequest(username))
            chat = result.chats[0] if hasattr(result, 'chats') else result.chat
        
        chat_title = getattr(chat, 'title', 'Unknown Group')
        print(f"{Colors.GREEN}Berhasil bergabung dengan grup: {chat_title}{Colors.ENDC}")
        return chat
    except Exception as e:
        print(f"{Colors.FAIL}Gagal bergabung dengan grup: {str(e)}{Colors.ENDC}")
        return None

async def get_members(client, chat):
    members = []
    async for user in client.iter_participants(chat):
        members.append((user.id, user.first_name, user.last_name, user.username))
    return members

async def find_and_save_group_links(client, chat):
    pattern = r'(https?://)?t\.me/(\w+)|@(\w+)'
    group_links = set()

    async for message in client.iter_messages(chat):
        if message.text:
            matches = re.findall(pattern, message.text)
            for match in matches:
                if match[1]:  # URL format
                    group_links.add(match[1])
                elif match[2]:  # @username format
                    group_links.add(match[2])

    valid_groups = 0
    for link in group_links:
        if await validate_and_add_group_username(client, link):
            valid_groups += 1
    
    print(f"{Colors.CYAN}Ditemukan {len(group_links)} link/username.{Colors.ENDC}")
    print(f"{Colors.GREEN}Berhasil menyimpan {valid_groups} username grup yang valid.{Colors.ENDC}")

def print_total_usernames():
    try:
        with open(SCRAPE_FILE, 'r', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            total = sum(1 for row in reader)
        
        if total > 0:
            print(f"{Colors.CYAN}Total Grup Yang Ada : {total}{Colors.ENDC}")
        else:
            print(f"{Colors.WARNING}File {SCRAPE_FILE} kosong.{Colors.ENDC}")
    except FileNotFoundError:
        print(f"{Colors.WARNING}File {SCRAPE_FILE} tidak ditemukan.{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Terjadi kesalahan saat membaca file {SCRAPE_FILE}: {str(e)}{Colors.ENDC}")

async def main():
    ensure_scrape_file_exists()
    accounts = load_accounts()
    if not accounts:
        print(f"{Colors.FAIL}Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.{Colors.ENDC}")
        return

    clear_screen()
    print_centered_box("TELEGRAM AUTO JOIN", Colors.HEADER)
    print(f"{Colors.CYAN}Pilih akun yang akan digunakan:{Colors.ENDC}")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = get_user_choice(len(accounts))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    api_id = account['api_id']
    api_hash = account['api_hash']
    phone_number = account['phone_number']

    client = TelegramClient(f'session_{account_name}', api_id, api_hash)
    await client.start(phone=phone_number)

    while True:
        clear_screen()
        print_centered_box("TELEGRAM AUTO JOIN", Colors.HEADER)
        print_total_usernames()
        options = [
            "1. Bergabung dengan grup baru",
            "2. Cari link/username grup dari pesan di grup yang ada",
            "3. Bergabung dengan semua grup dari file",
            "0. Keluar"
        ]
        print_left_aligned_box("MENU UTAMA", options, Colors.BLUE)
        
        choice = get_user_choice(3)

        if choice == 1:
            link = input(f"{Colors.CYAN}Masukkan link/username grup: {Colors.ENDC}")
            chat = await join_group(client, link)
            if chat:
                username = getattr(chat, 'username', None)
                if username:
                    await add_group_username(username, chat.title)
                    print(f"{Colors.GREEN}Username grup {username} telah disimpan ke {SCRAPE_FILE}.{Colors.ENDC}")
                else:
                    print(f"{Colors.WARNING}Grup tidak memiliki username.{Colors.ENDC}")
                members = await get_members(client, chat)
                print(f"{Colors.GREEN}Berhasil menambahkan {len(members)} anggota ke database.{Colors.ENDC}")

        elif choice == 2:
            groups = []
            try:
                with open(SCRAPE_FILE, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    next(reader)  # Skip header
                    groups = list(reader)

                if not groups:
                    print(f"{Colors.WARNING}Tidak ada grup tersimpan di {SCRAPE_FILE}{Colors.ENDC}")
                else:
                    print(f"{Colors.CYAN}Daftar grup tersimpan:{Colors.ENDC}")
                    for i, (username, name) in enumerate(groups, 1):
                        print(f"{i}. {name} (@{username})")
                    
                    group_choice = get_user_choice(len(groups))
                    if group_choice != 0:
                        selected_group = groups[group_choice - 1]
                        try:
                            chat = await client.get_entity(selected_group[0])
                            await find_and_save_group_links(client, chat)
                        except Exception as e:
                            print(f"{Colors.FAIL}Terjadi kesalahan: {str(e)}{Colors.ENDC}")
            except StopIteration:
                print(f"{Colors.WARNING}File {SCRAPE_FILE} kosong atau hanya berisi header.{Colors.ENDC}")

        elif choice == 3:
            try:
                with open(SCRAPE_FILE, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    next(reader)  # Skip header
                    for row in reader:
                        if row:  # Check if row is not empty
                            username = row[0]
                            if await is_valid_group(client, username):
                                chat = await join_group(client, f"https://t.me/{username}")
                                if chat:
                                    print(f"{Colors.GREEN}Berhasil bergabung dengan grup: {username}{Colors.ENDC}")
                            else:
                                print(f"{Colors.WARNING}Melewati username yang bukan grup: {username}{Colors.ENDC}")
                print(f"{Colors.GREEN}Selesai bergabung dengan semua grup dari {SCRAPE_FILE}{Colors.ENDC}")
            except StopIteration:
                print(f"{Colors.WARNING}File {SCRAPE_FILE} kosong atau hanya berisi header.{Colors.ENDC}")

        elif choice == 0:
            break

        input(f"\n{Colors.GREEN}Tekan Enter untuk kembali ke menu utama...{Colors.ENDC}")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())