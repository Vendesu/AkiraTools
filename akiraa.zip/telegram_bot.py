import csv
import os
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import subprocess
import json
from datetime import datetime, timedelta
from collections import defaultdict

# Banner
BANNER = """
╔═══════════════════════════════════════════╗
║             TELEGRAM MESSAGE BOT          ║
║              Created by Akira             ║
╚═══════════════════════════════════════════╝
"""

LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")

def validate_license():
    if not os.path.exists(LICENSE_FILE):
        return False
    with open(LICENSE_FILE, 'r') as f:
        license_data = json.load(f)
    expiry_date = datetime.strptime(license_data['expiry'], '%Y-%m-%d')
    return datetime.now() < expiry_date

def get_license_info():
    with open(LICENSE_FILE, 'r') as f:
        license_data = json.load(f)
    expiry_date = datetime.strptime(license_data['expiry'], '%Y-%m-%d')
    remaining_days = (expiry_date - datetime.now()).days
    name = license_data['name']
    user_info = [
        f"Nama    : {name}",
        f"Lisensi : {remaining_days} hari tersisa"
    ]
    return user_info

def save_message(message):
    existing_messages = []
    try:
        with open('pesan.csv', 'r', newline='', encoding='utf-8') as file:
            reader = csv.reader(file)
            existing_messages = list(reader)
    except FileNotFoundError:
        pass

    if existing_messages:
        existing_messages.pop(0)

    existing_messages.append([message])

    with open('pesan.csv', 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(existing_messages)

    print("Pesan berhasil disimpan ke pesan.csv")

def create_markup():
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(InlineKeyboardButton("⚙️ Settings", callback_data="settings"),
               InlineKeyboardButton("💬 Chat Admin", url="https://t.me/akiradigitalstore"))
    return markup

last_messages = defaultdict(lambda: None)

def start_bot(token, user_id):
    bot = telebot.TeleBot(token)

    @bot.message_handler(commands=['start'])
    def send_welcome(message):
        if not validate_license():
            bot.reply_to(message, "❌ Lisensi tidak valid atau telah kedaluwarsa.")
            return

        user_info = get_license_info()
        welcome_text = f"""
🎉 Selamat datang di Bot Otomasi Telegram! 🤖

👤 {user_info[0]}
⏳ {user_info[1]}

Silakan kirim pesan untuk disimpan atau pilih opsi di bawah:
        """
        bot.reply_to(message, welcome_text, reply_markup=create_markup())

    @bot.message_handler(func=lambda message: str(message.from_user.id) == user_id)
    def handle_message(message):
        if not validate_license():
            bot.reply_to(message, "❌ Lisensi tidak valid atau telah kedaluwarsa.")
            return

        chat_id = message.chat.id
        
        if last_messages[chat_id]:
            try:
                bot.delete_message(chat_id, last_messages[chat_id])
            except Exception as e:
                print(f"Error deleting message: {e}")

        save_message(message.text)
        
        confirmation = bot.reply_to(message, "✅ Pesan Anda telah disimpan.")
        last_messages[chat_id] = confirmation.message_id

        send_welcome(message)

    @bot.callback_query_handler(func=lambda call: True)
    def callback_query(call):
        if call.data == "settings":
            bot.answer_callback_query(call.id, "⚙️ Pengaturan belum tersedia.")

    print("Bot sedang berjalan. Tekan Ctrl+C untuk menghentikan.")
    bot.polling()

def run_in_screen(token, user_id):
    script_content = f"""
import telebot
import csv
import os
import json
from datetime import datetime
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from collections import defaultdict

LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")

def validate_license():
    if not os.path.exists(LICENSE_FILE):
        return False
    with open(LICENSE_FILE, 'r') as f:
        license_data = json.load(f)
    expiry_date = datetime.strptime(license_data['expiry'], '%Y-%m-%d')
    return datetime.now() < expiry_date

def get_license_info():
    with open(LICENSE_FILE, 'r') as f:
        license_data = json.load(f)
    expiry_date = datetime.strptime(license_data['expiry'], '%Y-%m-%d')
    remaining_days = (expiry_date - datetime.now()).days
    name = license_data['name']
    user_info = [
        f"Nama    : {{name}}",
        f"Lisensi : {{remaining_days}} hari tersisa"
    ]
    return user_info

def save_message(message):
    existing_messages = []
    try:
        with open('pesan.csv', 'r', newline='', encoding='utf-8') as file:
            reader = csv.reader(file)
            existing_messages = list(reader)
    except FileNotFoundError:
        pass

    if existing_messages:
        existing_messages.pop(0)

    existing_messages.append([message])

    with open('pesan.csv', 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(existing_messages)

    print("Pesan berhasil disimpan ke pesan.csv")

def create_markup():
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(InlineKeyboardButton("⚙️ Settings", callback_data="settings"),
               InlineKeyboardButton("💬 Chat Admin", url="https://t.me/akiradigitalstore"))
    return markup

last_messages = defaultdict(lambda: None)

bot = telebot.TeleBot("{token}")

@bot.message_handler(commands=['start'])
def send_welcome(message):
    if not validate_license():
        bot.reply_to(message, "❌ Lisensi tidak valid atau telah kedaluwarsa.")
        return

    user_info = get_license_info()
    welcome_text = f"""
🎉 Selamat datang di Bot Otomasi Telegram! 🤖

👤 {{user_info[0]}}
⏳ {{user_info[1]}}

Silakan kirim pesan untuk disimpan atau pilih opsi di bawah:
    """
    bot.reply_to(message, welcome_text, reply_markup=create_markup())

@bot.message_handler(func=lambda message: str(message.from_user.id) == "{user_id}")
def handle_message(message):
    if not validate_license():
        bot.reply_to(message, "❌ Lisensi tidak valid atau telah kedaluwarsa.")
        return

    chat_id = message.chat.id
    
    if last_messages[chat_id]:
        try:
            bot.delete_message(chat_id, last_messages[chat_id])
        except Exception as e:
            print(f"Error deleting message: {{e}}")

    save_message(message.text)
    
    confirmation = bot.reply_to(message, "✅ Pesan Anda telah disimpan.")
    last_messages[chat_id] = confirmation.message_id

    send_welcome(message)

@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.data == "settings":
        bot.answer_callback_query(call.id, "⚙️ Pengaturan belum tersedia.")

bot.polling()
    """
    
    with open('temp_bot.py', 'w') as f:
        f.write(script_content)
    
    subprocess.run(['screen', '-dmS', 'telegram_bot', 'python', 'temp_bot.py'])
    print("Bot telah dijalankan di screen session.")

def main():
    print(BANNER)
    if not validate_license():
        print("❌ Lisensi tidak valid atau telah kedaluwarsa.")
        return
    
    token = input("Masukkan token bot Telegram: ")
    user_id = input("Masukkan ID pengguna yang diizinkan: ")

    run_in_screen(token, user_id)
    print("Kembali ke menu utama...")

if __name__ == "__main__":
    main()