import csv
import os
import json
import logging
import subprocess
from telegram import Update, Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes

# Konfigurasi logging
logging.basicConfig(level=logging.INFO)

# File untuk menyimpan konfigurasi
CONFIG_FILE = 'bot_config.json'

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║{text.center(width - 2)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_left_aligned_box(title, content, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║ {title.ljust(width - 3)}║")
    print(f"╠{'═' * (width - 2)}╣")
    for line in content:
        print(f"║ {line.ljust(width - 3)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f)

async def save_message(message):
    try:
        with open('pesan.csv', 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow([message])
        logging.info("Pesan terbaru berhasil disimpan ke pesan.csv")
    except IOError:
        logging.error("Gagal menyimpan pesan")

def create_markup():
    keyboard = [
        [InlineKeyboardButton("⚙️ Settings", callback_data="settings"),
         InlineKeyboardButton("🗑️ Hapus Pesan", callback_data="delete_messages")],
        [InlineKeyboardButton("💬 Chat Admin", url="https://t.me/akiradigitalstore")]
    ]
    return InlineKeyboardMarkup(keyboard)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = """
🎉 Selamat datang di Bot Otomasi Telegram! 🤖

Silakan kirim pesan untuk disimpan atau pilih opsi di bawah:
    """
    await update.message.reply_text(welcome_text, reply_markup=create_markup())

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    
    if 'last_message' in context.chat_data:
        try:
            await context.bot.delete_message(chat_id, context.chat_data['last_message'])
        except Exception as e:
            logging.error(f"Error deleting message: {e}")

    await save_message(update.message.text)
    
    confirmation = await update.message.reply_text("✅ Pesan Anda telah disimpan.")
    context.chat_data['last_message'] = confirmation.message_id

    await start(update, context)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "settings":
        await query.edit_message_text("⚙️ Pengaturan belum tersedia.")
    elif query.data == "delete_messages":
        try:
            with open('pesan.csv', 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([])  # Menulis baris kosong untuk menghapus semua pesan
            await query.edit_message_text("✅ Semua pesan berhasil dihapus.")
        except IOError:
            await query.edit_message_text("❌ Gagal menghapus pesan.")
        
        # Tampilkan kembali menu utama setelah beberapa detik
        context.job_queue.run_once(lambda _: show_main_menu(update, context), 3)

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    welcome_text = """
🎉 Selamat datang di Bot Otomasi Telegram! 🤖

Silakan kirim pesan untuk disimpan atau pilih opsi di bawah:
    """
    await context.bot.send_message(chat_id, welcome_text, reply_markup=create_markup())

def configure_bot():
    config = load_config()
    config['token'] = input(f"{Colors.GREEN}Masukkan token bot Telegram: {Colors.ENDC}")
    config['user_id'] = input(f"{Colors.GREEN}Masukkan ID pengguna yang diizinkan: {Colors.ENDC}")
    save_config(config)
    print(f"{Colors.GREEN}Konfigurasi berhasil disimpan.{Colors.ENDC}")
    input(f"{Colors.WARNING}Tekan Enter untuk kembali ke menu utama...{Colors.ENDC}")

def start_bot():
    config = load_config()
    if 'token' not in config or 'user_id' not in config:
        print(f"{Colors.FAIL}Bot belum dikonfigurasi. Silakan konfigurasi terlebih dahulu.{Colors.ENDC}")
        input(f"{Colors.WARNING}Tekan Enter untuk kembali ke menu utama...{Colors.ENDC}")
        return

    screen_name = "telegram_bot"
    
    # Cek apakah screen sudah ada
    check_screen = subprocess.run(["screen", "-list"], capture_output=True, text=True)
    if screen_name in check_screen.stdout:
        print(f"{Colors.WARNING}Bot sudah berjalan di screen. Menghentikan dan memulai ulang...{Colors.ENDC}")
        subprocess.run(["screen", "-S", screen_name, "-X", "quit"])

    # Jalankan bot di screen baru
    current_file = os.path.abspath(__file__)
    command = f"python3 {current_file} run_bot {config['token']} {config['user_id']}"
    try:
        subprocess.run(["screen", "-dmS", screen_name, "bash", "-c", command])
        print(f"{Colors.GREEN}Bot berhasil dijalankan di background (screen: {screen_name}).{Colors.ENDC}")
    except subprocess.CalledProcessError as e:
        print(f"{Colors.FAIL}Gagal menjalankan bot: {e}{Colors.ENDC}")
    
    input(f"{Colors.WARNING}Tekan Enter untuk kembali ke menu utama...{Colors.ENDC}")

def run_bot(token, user_id):
    application = Application.builder().token(token).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & filters.User(int(user_id)), handle_message))
    application.add_handler(CallbackQueryHandler(button))

    print(f"{Colors.GREEN}Bot sedang berjalan. Gunakan 'screen -r telegram_bot' untuk melihat output.{Colors.ENDC}")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

def main_menu():
    while True:
        clear_screen()
        print_centered_box("TELEGRAM AUTOMATION TOOL", Colors.HEADER)
        print_centered_box("Created By Akira", Colors.CYAN)
        
        menu_items = [
            "1. Konfigurasi Bot Telegram",
            "2. Start Bot di Screen",
            "3. Kembali ke Menu Utama"
        ]
        print_left_aligned_box("MENU BOT TELEGRAM", menu_items, Colors.BLUE)
        
        choice = input(f"{Colors.GREEN}Pilih menu: {Colors.ENDC}")
        
        if choice == '1':
            configure_bot()
        elif choice == '2':
            start_bot()
        elif choice == '3':
            break
        else:
            print(f"{Colors.FAIL}Pilihan tidak valid.{Colors.ENDC}")
            input(f"{Colors.WARNING}Tekan Enter untuk melanjutkan...{Colors.ENDC}")

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "run_bot":
        run_bot(sys.argv[2], sys.argv[3])
    else:
        main_menu()