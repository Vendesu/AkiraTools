import csv
import os
import json
from datetime import datetime
import logging
from collections import defaultdict
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

# Konfigurasi logging
logging.basicConfig(level=logging.INFO)

LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")

# Cache untuk lisensi
license_cache = {}

async def validate_license():
    if 'expiry' in license_cache:
        return datetime.now() < license_cache['expiry']
    
    try:
        with open(LICENSE_FILE, 'r') as f:
            license_data = json.load(f)
        expiry_date = datetime.strptime(license_data['expiry'], '%Y-%m-%d')
        license_cache['expiry'] = expiry_date
        return datetime.now() < expiry_date
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        logging.error("Lisensi tidak valid atau file rusak")
        return False

async def get_license_info():
    try:
        with open(LICENSE_FILE, 'r') as f:
            license_data = json.load(f)
        expiry_date = datetime.strptime(license_data['expiry'], '%Y-%m-%d')
        remaining_days = (expiry_date - datetime.now()).days
        name = license_data['name']
        return [
            f"Nama    : {name}",
            f"Lisensi : {remaining_days} hari tersisa"
        ]
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        logging.error("Gagal membaca informasi lisensi")
        return ["Informasi lisensi tidak tersedia"]

async def save_message(message):
    try:
        with open('pesan.csv', 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow([message])
        logging.info("Pesan berhasil disimpan ke pesan.csv")
    except IOError:
        logging.error("Gagal menyimpan pesan")

def create_markup():
    markup = types.InlineKeyboardMarkup()
    markup.row(
        types.InlineKeyboardButton("⚙️ Settings", callback_data="settings"),
        types.InlineKeyboardButton("💬 Chat Admin", url="https://t.me/akiradigitalstore")
    )
    return markup

async def start_bot(token, user_id):
    bot = Bot(token=token)
    dp = Dispatcher(bot)
    last_messages = defaultdict(lambda: None)

    @dp.message_handler(commands=['start'])
    async def send_welcome(message: types.Message):
        if not await validate_license():
            await message.reply("❌ Lisensi tidak valid atau telah kedaluwarsa.")
            return

        user_info = await get_license_info()
        welcome_text = f"""
    🎉 Selamat datang di Bot Otomasi Telegram! 🤖

    👤 {user_info[0]}
    ⏳ {user_info[1]}

    Silakan kirim pesan untuk disimpan atau pilih opsi di bawah:
        """
        await message.reply(welcome_text, reply_markup=create_markup())

    @dp.message_handler(lambda message: str(message.from_user.id) == user_id)
    async def handle_message(message: types.Message):
        if not await validate_license():
            await message.reply("❌ Lisensi tidak valid atau telah kedaluwarsa.")
            return

        chat_id = message.chat.id
        
        if last_messages[chat_id]:
            try:
                await bot.delete_message(chat_id, last_messages[chat_id])
            except Exception as e:
                logging.error(f"Error deleting message: {e}")

        await save_message(message.text)
        
        confirmation = await message.reply("✅ Pesan Anda telah disimpan.")
        last_messages[chat_id] = confirmation.message_id

        await send_welcome(message)

    @dp.callback_query_handler(lambda call: True)
    async def callback_query(call: types.CallbackQuery):
        if call.data == "settings":
            await call.answer("⚙️ Pengaturan belum tersedia.")

    await dp.start_polling()

def main():
    print("""
    ╔═══════════════════════════════════════════╗
    ║             TELEGRAM MESSAGE BOT          ║
    ║              Created by Akira             ║
    ╚═══════════════════════════════════════════╝
    """)

    if not asyncio.run(validate_license()):
        print("❌ Lisensi tidak valid atau telah kedaluwarsa.")
        return
    
    token = input("Masukkan token bot Telegram: ")
    user_id = input("Masukkan ID pengguna yang diizinkan: ")

    print("Bot sedang berjalan. Tekan Ctrl+C untuk menghentikan.")
    asyncio.run(start_bot(token, user_id))

if __name__ == '__main__':
    main()