from telethon import TelegramClient
import json

async def main():
    client = TelegramClient('session', None, None)
    await client.start()

    group = await client.get_entity('https://t.me/nama_grup')
    
    messages = []
    async for message in client.iter_messages(group, limit=1000):
        messages.append({
            'id': message.id,
            'sender': str(message.sender_id),
            'text': message.text,
            'date': str(message.date)
        })
    
    with open('chat_backup.json', 'w', encoding='utf-8') as f:
        json.dump(messages, f, ensure_ascii=False, indent=4)
    
    print("Backup chat berhasil disimpan ke chat_backup.json")

    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())