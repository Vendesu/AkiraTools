from telethon import TelegramClient
import asyncio
import os

async def backup_chat(client, chat, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    messages = await client.get_messages(chat, limit=None)
    
    filename = f"{output_dir}/{chat.title}.txt"
    with open(filename, 'w', encoding='utf-8') as f:
        for message in reversed(messages):
            sender = await message.get_sender()
            f.write(f"[{message.date}] {sender.first_name}: {message.text}\n")
    
    print(f"Backup chat selesai: {filename}")

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    chat_name = input("Masukkan username atau ID chat/grup: ")
    output_dir = input("Masukkan direktori output: ")

    chat = await client.get_entity(chat_name)
    await backup_chat(client, chat, output_dir)

    await client.disconnect()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))