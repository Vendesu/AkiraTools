from telethon import TelegramClient
from collections import Counter

async def main():
    client = TelegramClient('session', None, None)
    await client.start()

    group = await client.get_entity('https://t.me/nama_grup')
    
    message_count = Counter()
    async for message in client.iter_messages(group, limit=1000):
        message_count[message.sender_id] += 1
    
    print("Statistik Grup:")
    print(f"Total pesan: {sum(message_count.values())}")
    print("Top 5 pengirim pesan:")
    for user_id, count in message_count.most_common(5):
        user = await client.get_entity(user_id)
        print(f"- {user.first_name}: {count} pesan")

    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())