from telethon import TelegramClient
import asyncio
from datetime import datetime, timedelta

async def get_group_stats(client, group):
    participants = await client.get_participants(group)
    messages = await client.get_messages(group, limit=1000)

    total_members = len(participants)
    active_members = sum(1 for m in participants if m.status.was_online and (datetime.now() - m.status.was_online) <= timedelta(days=7))
    messages_per_day = len(messages) / 7  # Asumsi 1000 pesan terakhir dalam 7 hari

    return {
        "total_members": total_members,
        "active_members": active_members,
        "messages_per_day": messages_per_day
    }

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    group = input("Masukkan username atau ID grup: ")
    stats = await get_group_stats(client, group)

    print(f"Statistik Grup:")
    print(f"Total Anggota: {stats['total_members']}")
    print(f"Anggota Aktif (7 hari terakhir): {stats['active_members']}")
    print(f"Rata-rata Pesan per Hari: {stats['messages_per_day']:.2f}")

    await client.disconnect()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))