from telethon import TelegramClient
import asyncio
import os

async def download_media(client, chat, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    async for message in client.iter_messages(chat):
        if message.media:
            path = await message.download_media(file=output_dir)
            print(f'File tersimpan ke {path}')

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    chat_name = input("Masukkan username atau ID chat/grup: ")
    output_dir = input("Masukkan direktori output: ")

    chat = await client.get_entity(chat_name)
    await download_media(client, chat, output_dir)

    await client.disconnect()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))