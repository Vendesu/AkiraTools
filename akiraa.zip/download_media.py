from telethon import TelegramClient
import os

async def main():
    client = TelegramClient('session', None, None)
    await client.start()

    group = await client.get_entity('https://t.me/nama_grup')
    
    if not os.path.exists('downloads'):
        os.makedirs('downloads')
    
    async for message in client.iter_messages(group, limit=100):
        if message.media:
            path = await message.download_media(file='downloads/')
            print(f"Media diunduh: {path}")

    print("Pengunduhan media selesai.")

    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())