from telethon import TelegramClient, errors
import asyncio
import csv
import json
import os
import re

ACCOUNTS_FILE = 'telegram_accounts.json'
LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")
GROUPS_FILE = 'matched_groups.csv'

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    YELLOW = '\033[93m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║{text.center(width - 2)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def get_local_license():
    try:
        with open(LICENSE_FILE, 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        return None

def get_message_from_csv():
    try:
        with open('pesan.csv', 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            messages = list(reader)
            if messages:
                return messages[0][0]  # Mengambil pesan pertama dari file
            else:
                return "Tidak ada pesan di file pesan.csv"
    except FileNotFoundError:
        return "File pesan.csv tidak ditemukan"
    except Exception as e:
        return f"Error saat membaca pesan.csv: {str(e)}"

async def check_and_save_groups(client, keywords):
    matched_groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group or dialog.is_channel:
            if hasattr(dialog.entity, 'forum') and dialog.entity.forum:
                try:
                    async for message in client.iter_messages(dialog.entity, search=keywords, limit=1):
                        if message.reply_to:
                            matched_groups.append((dialog.name, dialog.id, message.id))
                            print(f"Grup dengan topik yang cocok ditemukan: {dialog.name}")
                            break
                except Exception as e:
                    print(f"Error saat memeriksa grup {dialog.name}: {str(e)}")
    
    with open(GROUPS_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Group Name', 'Group ID', 'Message ID'])
        writer.writerows(matched_groups)
    
    print(f"Daftar grup yang cocok telah disimpan di {GROUPS_FILE}")
    return matched_groups

async def send_message_to_group(client, group_id, message_id, message):
    try:
        await client.send_message(group_id, message, reply_to=message_id)
        print(f"Pesan terkirim ke grup: {group_id}")
    except Exception as e:
        print(f"Gagal mengirim pesan ke grup {group_id}: {str(e)}")

async def main():
    clear_screen()
    print_centered_box("TELEGRAM AUTOMATION TOOL", Colors.HEADER)
    print_centered_box("Created By Akira", Colors.CYAN)
    print_centered_box("KIRIM PESAN KE GRUP TOPIK", Colors.GREEN)

    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.")
        return

    print("Pilih akun yang akan digunakan:")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = int(input("Masukkan nomor akun: "))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    api_id = account['api_id']
    api_hash = account['api_hash']
    phone_number = account['phone_number']

    client = TelegramClient(f'session_{account_name}', api_id, api_hash)
    await client.start(phone=phone_number)

    keywords = input("Masukkan kata kunci untuk mencari topik (pisahkan dengan OR jika lebih dari satu): ")
    matched_groups = await check_and_save_groups(client, keywords)

    if not matched_groups:
        print("Tidak ada grup yang cocok ditemukan.")
        await client.disconnect()
        return

    local_license = get_local_license()
    if not local_license:
        print("Lisensi lokal tidak ditemukan. Jalankan installer kembali.")
        await client.disconnect()
        return

    choice = input("Pilih metode pengiriman (1: Input langsung, 2: Dari file pesan.csv): ")

    if choice == "1":
        message = input("Masukkan pesan yang ingin dikirim ke semua grup: ")
    elif choice == "2":
        message = get_message_from_csv()
        print(f"Pesan dari file pesan.csv: {message}")
    else:
        print("Pilihan tidak valid.")
        await client.disconnect()
        return

    print(f"Pesan yang akan dikirim: {message}")

    for group_name, group_id, message_id in matched_groups:
        await send_message_to_group(client, group_id, message_id, message)

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())