from telethon import TelegramClient, errors
import asyncio
import csv
import json
import os
import time

ACCOUNTS_FILE = 'telegram_accounts.json'

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    YELLOW = '\033[93m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║{text.center(width - 2)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_left_aligned_box(title, content, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║ {title.ljust(width - 3)}║")
    print(f"╠{'═' * (width - 2)}╣")
    for line in content:
        print(f"║ {line.ljust(width - 3)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def loading_animation():
    animation = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    for i in range(20):
        time.sleep(0.1)
        print(f"\r{Colors.BLUE}Memuat {animation[i % len(animation)]}", end="")
    print(f"\r{' ' * 20}\r", end="")

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def load_groups():
    groups = []
    try:
        with open('grup_id.csv', 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                groups.append((row['Group Name'], int(row['Group ID'])))
    except FileNotFoundError:
        print(f"{Colors.FAIL}File grup_id.csv tidak ditemukan.{Colors.ENDC}")
    return groups

def get_message_from_csv():
    try:
        with open('pesan.csv', 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if content:
                return content
            else:
                return "Tidak ada pesan di file pesan.csv"
    except FileNotFoundError:
        return "File pesan.csv tidak ditemukan"
    except Exception as e:
        return f"Error saat membaca pesan.csv: {str(e)}"

async def send_message_to_group(client, group_id, message):
    try:
        entity = await client.get_entity(group_id)
        
        if hasattr(entity, 'forum') and entity.forum:
            print(f"{Colors.YELLOW}Melewati grup dengan tipe topik: {entity.title}{Colors.ENDC}")
            return
        
        await client.send_message(entity, message)
        print(f"{Colors.GREEN}Pesan terkirim ke grup: {entity.title}{Colors.ENDC}")
    except errors.ChatAdminRequiredError:
        print(f"{Colors.FAIL}Gagal mengirim pesan ke grup {entity.title}: Anda bukan admin grup{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Gagal mengirim pesan ke grup {group_id}: {str(e)}{Colors.ENDC}")

async def main_menu():
    while True:
        clear_screen()
        print_centered_box("AUTO SEND GRUP", Colors.HEADER)
        
        menu_items = [
            "1. Pilih Akun",
            "2. Kirim Pesan ke Grup",
            "3. Kembali ke Menu Utama"
        ]
        print_left_aligned_box("MENU", menu_items, Colors.BLUE)
        
        choice = input(f"{Colors.GREEN}Pilih menu: {Colors.ENDC}")
        
        if choice == '1':
            await choose_account()
        elif choice == '2':
            await send_messages()
        elif choice == '3':
            break
        else:
            print(f"{Colors.FAIL}Pilihan tidak valid. Silakan coba lagi.{Colors.ENDC}")
            time.sleep(1)

async def choose_account():
    accounts = load_accounts()
    if not accounts:
        print(f"{Colors.FAIL}Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.{Colors.ENDC}")
        input("Tekan Enter untuk kembali...")
        return

    print(f"{Colors.CYAN}Pilih akun yang akan digunakan:{Colors.ENDC}")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = int(input(f"{Colors.GREEN}Masukkan nomor akun: {Colors.ENDC}"))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    global client
    client = TelegramClient(f'session_{account_name}', account['api_id'], account['api_hash'])
    await client.start(phone=account['phone_number'])
    print(f"{Colors.GREEN}Berhasil login dengan akun {account_name}{Colors.ENDC}")
    input("Tekan Enter untuk kembali...")

async def send_messages():
    if not 'client' in globals():
        print(f"{Colors.FAIL}Silakan pilih akun terlebih dahulu.{Colors.ENDC}")
        input("Tekan Enter untuk kembali...")
        return

    groups = load_groups()
    if not groups:
        print(f"{Colors.FAIL}Tidak ada grup yang ditemukan di grup_id.csv{Colors.ENDC}")
        input("Tekan Enter untuk kembali...")
        return

    print(f"{Colors.CYAN}Pilih metode pengiriman:{Colors.ENDC}")
    print("1. Input langsung")
    print("2. Dari file pesan.csv")
    choice = input(f"{Colors.GREEN}Pilihan Anda: {Colors.ENDC}")

    if choice == "1":
        message = input(f"{Colors.GREEN}Masukkan pesan yang ingin dikirim ke semua grup: {Colors.ENDC}")
    elif choice == "2":
        message = get_message_from_csv()
        print(f"{Colors.CYAN}Pesan dari file pesan.csv: {message}{Colors.ENDC}")
    else:
        print(f"{Colors.FAIL}Pilihan tidak valid.{Colors.ENDC}")
        input("Tekan Enter untuk kembali...")
        return

    for group_name, group_id in groups:
        await send_message_to_group(client, group_id, message)

    input(f"{Colors.GREEN}Pengiriman pesan selesai. Tekan Enter untuk kembali...{Colors.ENDC}")

if __name__ == '__main__':
    asyncio.run(main_menu())