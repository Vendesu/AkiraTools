from telethon import TelegramClient, errors
import asyncio
import csv
import json
import requests

def load_credentials():
    try:
        with open('credentials.json', 'r') as f:
            credentials = json.load(f)
        return credentials['api_id'], credentials['api_hash']
    except FileNotFoundError:
        return None, None

def load_groups():
    groups = []
    try:
        with open('grup_id.csv', 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                groups.append((row['Group Name'], int(row['Group ID'])))
    except FileNotFoundError:
        print("File grup_id.csv tidak ditemukan.")
    return groups

def get_message_from_github():
    licenses_url = "https://raw.githubusercontent.com/Vendesu/ijin/main/licenses.txt"
    message_url = "https://raw.githubusercontent.com/Vendesu/ijin/main/pesan.txt"
    
    try:
        licenses = requests.get(licenses_url).text.strip().split('\n')
        message = requests.get(message_url).text.strip()
        
        if not message:
            return "tidak ada teks tersedia silahkan input di bot telegram"
        
        for license in licenses:
            if license in message:
                return message.replace(license, f"{license},")
        
        return message
    except:
        return "Error fetching message from GitHub"

async def send_message_to_group(client, group_id, message):
    try:
        entity = await client.get_entity(group_id)
        
        if hasattr(entity, 'forum') and entity.forum:
            async for topic in client.iter_messages(entity, search="lapak OR marketplace OR market", limit=1):
                if topic.is_topic_message:
                    await client.send_message(entity, message, reply_to=topic.id)
                    print(f"Pesan terkirim ke subtopik di grup: {entity.title}")
                    return
            
            await client.send_message(entity, message)
            print(f"Pesan terkirim ke grup utama: {entity.title}")
        else:
            await client.send_message(entity, message)
            print(f"Pesan terkirim ke grup: {entity.title}")
    except errors.ChatAdminRequiredError:
        print(f"Gagal mengirim pesan ke grup {entity.title}: Anda bukan admin grup")
    except Exception as e:
        print(f"Gagal mengirim pesan ke grup {group_id}: {str(e)}")

async def main():
    api_id, api_hash = load_credentials()
    if not api_id or not api_hash:
        print("Kredensial tidak ditemukan. Jalankan login.py terlebih dahulu.")
        return

    client = TelegramClient('session', api_id, api_hash)
    await client.start()

    groups = load_groups()
    if not groups:
        print("Tidak ada grup yang ditemukan di grup_id.csv")
        return

    choice = input("Pilih metode pengiriman (1: Input langsung, 2: Dari bot Telegram): ")

    if choice == "1":
        message = input("Masukkan pesan yang ingin dikirim ke semua grup: ")
    elif choice == "2":
        message = get_message_from_github()
        print(f"Pesan dari bot Telegram: {message}")
    else:
        print("Pilihan tidak valid.")
        return

    for group_name, group_id in groups:
        await send_message_to_group(client, group_id, message)

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())