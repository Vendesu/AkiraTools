from telethon import TelegramClient, errors
import asyncio
import csv
import json
import requests
import os

ACCOUNTS_FILE = 'telegram_accounts.json'
LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")
LICENSE_URL = "https://raw.githubusercontent.com/Vendesu/ijin/main/licenses.txt"

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def load_groups():
    groups = []
    try:
        with open('grup_id.csv', 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                groups.append((row['Group Name'], int(row['Group ID'])))
    except FileNotFoundError:
        print("File grup_id.csv tidak ditemukan.")
    return groups

def get_local_license():
    try:
        with open(LICENSE_FILE, 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        return None

def get_message_from_github(local_license):
    licenses_url = "https://raw.githubusercontent.com/Vendesu/ijin/main/licenses.txt"
    messages_url = "https://raw.githubusercontent.com/Vendesu/ijin/main/pesan.txt"
    
    try:
        licenses_response = requests.get(licenses_url)
        messages_response = requests.get(messages_url)
        
        if licenses_response.status_code != 200 or messages_response.status_code != 200:
            return "Error: Tidak dapat mengambil data dari GitHub"
        
        licenses = licenses_response.text.strip().split('\n')
        messages = messages_response.text.strip().split('\n')
        
        license_messages = {}
        for license, message in zip(licenses, messages):
            license_name = license.split(',')[0].strip()
            license_messages[license_name] = message
        
        if local_license in license_messages:
            return license_messages[local_license]
        else:
            return "Lisensi tidak valid atau pesan tidak tersedia"
    except Exception as e:
        return f"Error: {str(e)}"

async def send_message_to_group(client, group_id, message):
    try:
        entity = await client.get_entity(group_id)
        
        if hasattr(entity, 'forum') and entity.forum:
            async for topic in client.iter_messages(entity, search="lapak OR marketplace OR market", limit=1):
                if topic.is_topic_message:
                    await client.send_message(entity, message, reply_to=topic.id)
                    print(f"Pesan terkirim ke subtopik di grup: {entity.title}")
                    return
            
            await client.send_message(entity, message)
            print(f"Pesan terkirim ke grup utama: {entity.title}")
        else:
            await client.send_message(entity, message)
            print(f"Pesan terkirim ke grup: {entity.title}")
    except errors.ChatAdminRequiredError:
        print(f"Gagal mengirim pesan ke grup {entity.title}: Anda bukan admin grup")
    except Exception as e:
        print(f"Gagal mengirim pesan ke grup {group_id}: {str(e)}")

async def main():
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.")
        return

    print("Pilih akun yang akan digunakan:")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = int(input("Masukkan nomor akun: "))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    api_id = account['api_id']
    api_hash = account['api_hash']
    phone_number = account['phone_number']

    client = TelegramClient(f'session_{account_name}', api_id, api_hash)
    await client.start(phone=phone_number)

    groups = load_groups()
    if not groups:
        print("Tidak ada grup yang ditemukan di grup_id.csv")
        return

    local_license = get_local_license()
    if not local_license:
        print("Lisensi lokal tidak ditemukan. Jalankan installer kembali.")
        return

    choice = input("Pilih metode pengiriman (1: Input langsung, 2: Dari bot Telegram): ")

    if choice == "1":
        message = input("Masukkan pesan yang ingin dikirim ke semua grup: ")
    elif choice == "2":
        message = get_message_from_github(local_license)
        print(f"Pesan dari bot Telegram: {message}")
    else:
        print("Pilihan tidak valid.")
        return

    for group_name, group_id in groups:
        await send_message_to_group(client, group_id, message)

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())