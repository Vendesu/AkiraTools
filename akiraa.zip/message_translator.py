from telethon import TelegramClient, events
from googletrans import Translator

translator = Translator()

@events.register(events.NewMessage(pattern='/translate'))
async def translate_message(event):
    try:
        original_message = await event.get_reply_message()
        translated = translator.translate(original_message.text, dest='en')
        await event.reply(f"Terjemahan: {translated.text}")
    except Exception as e:
        await event.reply(f"Terjadi kesalahan: {str(e)}")

async def main():
    client = TelegramClient('session', None, None)
    client.add_event_handler(translate_message)
    
    await client.start()
    print("Penerjemah pesan berjalan...")
    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())