from telethon import TelegramClient, events
import asyncio
from googletrans import Translator

translator = Translator()

async def translate_message(message, dest='en'):
    try:
        translation = translator.translate(message, dest=dest)
        return translation.text
    except Exception as e:
        print(f"Error dalam penerjemahan: {e}")
        return message

async def setup_translator(client):
    @client.on(events.NewMessage(pattern='/translate'))
    async def translate_handler(event):
        if event.is_reply:
            replied = await event.get_reply_message()
            translated = await translate_message(replied.text)
            await event.reply(f"Terjemahan: {translated}")

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    await setup_translator(client)
    print("Penerjemah pesan aktif. Gunakan /translate untuk menerjemahkan pesan. Tekan Ctrl+C untuk berhenti.")
    await client.run_until_disconnected()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))