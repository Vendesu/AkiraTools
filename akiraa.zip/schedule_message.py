import schedule
import time
from telethon import TelegramClient

async def send_scheduled_message():
    async with TelegramClient('session', None, None) as client:
        await client.send_message('username_or_group', 'Ini adalah pesan terjadwal.')
        print("Pesan terjadwal terkirim!")

def schedule_message():
    schedule.every().day.at("10:00").do(lambda: asyncio.run(send_scheduled_message()))
    
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == '__main__':
    import asyncio
    schedule_message()