import schedule
import time
import json
from telethon import TelegramClient
import asyncio
from datetime import datetime, timedelta

def load_credentials():
    try:
        with open('credentials.json', 'r') as file:
            credentials = json.load(file)
        return credentials.get('api_id'), credentials.get('api_hash')
    except FileNotFoundError:
        return None, None

async def send_scheduled_message(api_id, api_hash, message, recipient):
    async with TelegramClient('session', api_id, api_hash) as client:
        await client.send_message(recipient, message)
        print("Pesan terjadwal terkirim!")

def schedule_message(api_id, api_hash, day, time_wib, message, recipient):
    # Konversi waktu WIB ke UTC
    time_utc = datetime.strptime(time_wib, "%H:%M") - timedelta(hours=7)
    schedule_time = f"{day.lower()} at {time_utc.strftime('%H:%M')}"
    
    schedule.every().day.at(schedule_time).do(lambda: asyncio.run(send_scheduled_message(api_id, api_hash, message, recipient)))
    
    print(f"Pesan dijadwalkan untuk {day} pukul {time_wib} WIB")
    while True:
        schedule.run_pending()
        time.sleep(1)

def get_user_input():
    days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu']
    
    while True:
        day = input("Masukkan hari (Senin-Minggu): ").lower()
        if day in days:
            break
        print("Hari tidak valid. Mohon masukkan hari yang benar.")
    
    while True:
        time_wib = input("Masukkan waktu WIB (format 24 jam, misalnya 14:30): ")
        if len(time_wib) == 5 and time_wib[2] == ':' and time_wib[:2].isdigit() and time_wib[3:].isdigit():
            hour, minute = map(int, time_wib.split(':'))
            if 0 <= hour < 24 and 0 <= minute < 60:
                break
        print("Format waktu tidak valid. Gunakan format 24 jam WIB (misalnya 14:30).")
    
    message = input("Masukkan pesan yang ingin dijadwalkan: ")
    recipient = input("Masukkan username atau ID grup tujuan: ")
    
    return day, time_wib, message, recipient

def main():
    api_id, api_hash = load_credentials()
    if not api_id or not api_hash:
        print("Kredensial tidak ditemukan. Harap jalankan login.py terlebih dahulu.")
        return

    day, time_wib, message, recipient = get_user_input()
    schedule_message(api_id, api_hash, day, time_wib, message, recipient)

if __name__ == '__main__':
    main()