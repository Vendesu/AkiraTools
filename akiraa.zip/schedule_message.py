from telethon import TelegramClient
import asyncio
from datetime import datetime, timedelta

async def schedule_message(client, target, message, schedule_time):
    now = datetime.now()
    delay = (schedule_time - now).total_seconds()
    if delay > 0:
        await asyncio.sleep(delay)
        await client.send_message(target, message)
        print(f"Pesan terjadwal terkirim ke {target}")
    else:
        print("Waktu yang dijadwalkan sudah lewat")

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    target = input("Masukkan username atau ID target: ")
    message = input("Masukkan pesan: ")
    schedule_time_str = input("Masukkan waktu pengiriman (format: YYYY-MM-DD HH:MM): ")
    schedule_time = datetime.strptime(schedule_time_str, "%Y-%m-%d %H:%M")

    await schedule_message(client, target, message, schedule_time)

    await client.disconnect()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))