import schedule
import time
import json
from telethon import TelegramClient
import asyncio
from datetime import datetime, timedelta

ACCOUNTS_FILE = 'telegram_accounts.json'

def load_accounts():
    try:
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"File {ACCOUNTS_FILE} tidak ditemukan.")
        return {}

async def send_scheduled_message(account_details, message, recipient):
    async with TelegramClient('session_' + account_details['phone_number'], account_details['api_id'], account_details['api_hash']) as client:
        await client.send_message(recipient, message)
        print(f"Pesan terjadwal terkirim dari akun {account_details['phone_number']}!")

def schedule_message(account_details, day, time_wib, message, recipient):
    time_utc = datetime.strptime(time_wib, "%H:%M") - timedelta(hours=7)
    schedule_time = f"{day.lower()} at {time_utc.strftime('%H:%M')}"
    
    schedule.every().day.at(schedule_time).do(lambda: asyncio.run(send_scheduled_message(account_details, message, recipient)))
    
    print(f"Pesan dijadwalkan untuk {day} pukul {time_wib} WIB dari akun {account_details['phone_number']}")
    while True:
        schedule.run_pending()
        time.sleep(1)

def get_user_input(accounts):
    days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu']
    
    print("Akun yang tersedia:")
    for name in accounts.keys():
        print(f"- {name}")
    
    while True:
        account_name = input("Pilih akun yang akan digunakan: ")
        if account_name in accounts:
            account_details = accounts[account_name]
            break
        print("Akun tidak ditemukan. Silakan coba lagi.")
    
    while True:
        day = input("Masukkan hari (Senin-Minggu): ").lower()
        if day in days:
            break
        print("Hari tidak valid. Mohon masukkan hari yang benar.")
    
    while True:
        time_wib = input("Masukkan waktu WIB (format 24 jam, misalnya 14:30): ")
        if len(time_wib) == 5 and time_wib[2] == ':' and time_wib[:2].isdigit() and time_wib[3:].isdigit():
            hour, minute = map(int, time_wib.split(':'))
            if 0 <= hour < 24 and 0 <= minute < 60:
                break
        print("Format waktu tidak valid. Gunakan format 24 jam WIB (misalnya 14:30).")
    
    message = input("Masukkan pesan yang ingin dijadwalkan: ")
    recipient = input("Masukkan username atau ID grup tujuan: ")
    
    return account_details, day, time_wib, message, recipient

def main():
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan. Harap tambahkan akun terlebih dahulu.")
        return

    account_details, day, time_wib, message, recipient = get_user_input(accounts)
    schedule_message(account_details, day, time_wib, message, recipient)

if __name__ == '__main__':
    main()