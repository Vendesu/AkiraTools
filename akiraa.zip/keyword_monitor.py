from telethon import TelegramClient, events
import asyncio

keywords = ['penting', 'urgent', 'segera']  # Ganti dengan kata kunci yang diinginkan

async def setup_keyword_monitor(client):
    @client.on(events.NewMessage(pattern='(?i)' + '|'.join(keywords)))
    async def keyword_handler(event):
        sender = await event.get_sender()
        print(f"Kata kunci terdeteksi dari {sender.first_name} {sender.last_name}: {event.text}")

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    await setup_keyword_monitor(client)
    print(f"Pemantau kata kunci aktif untuk: {', '.join(keywords)}. Tekan Ctrl+C untuk berhenti.")
    await client.run_until_disconnected()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))