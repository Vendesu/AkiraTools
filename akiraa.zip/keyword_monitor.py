from telethon import TelegramClient, events

keywords = ['penting', 'urgent', 'meeting']

@events.register(events.NewMessage(pattern='(?i).*'))
async def keyword_monitor(event):
    for keyword in keywords:
        if keyword.lower() in event.raw_text.lower():
            print(f"Kata kunci '{keyword}' terdeteksi dalam pesan: {event.raw_text}")
            # Di sini Anda bisa menambahkan notifikasi atau tindakan lain

async def main():
    client = TelegramClient('session', None, None)
    client.add_event_handler(keyword_monitor)
    
    await client.start()
    print("Pemantau kata kunci berjalan...")
    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())