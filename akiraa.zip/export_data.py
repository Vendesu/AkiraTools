from telethon import TelegramClient
import csv

async def main():
    client = TelegramClient('session', None, None)
    await client.start()

    group = await client.get_entity('https://t.me/nama_grup')
    
    with open('members.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Username', 'First Name', 'Last Name', 'User ID'])
        
        async for user in client.iter_participants(group):
            writer.writerow([user.username, user.first_name, user.last_name, user.id])
    
    print("Data anggota telah diekspor ke members.csv")

    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())