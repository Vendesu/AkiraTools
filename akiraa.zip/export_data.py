from telethon import TelegramClient
import asyncio
import csv

async def export_members(client, group, filename):
    members = await client.get_participants(group)
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['ID', 'Username', 'First Name', 'Last Name'])
        for member in members:
            writer.writerow([member.id, member.username, member.first_name, member.last_name])
    print(f"Data anggota telah diekspor ke {filename}")

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    group = input("Masukkan username atau ID grup: ")
    filename = input("Masukkan nama file untuk ekspor (contoh: members.csv): ")

    await export_members(client, group, filename)

    await client.disconnect()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))