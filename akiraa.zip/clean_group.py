from telethon import TelegramClient
from telethon.tl.types import ChannelParticipantsKicked
from datetime import datetime, timedelta

async def main():
    client = TelegramClient('session', None, None)
    await client.start()

    group = await client.get_entity('https://t.me/nama_grup')
    
    # Hapus pesan lama
    week_ago = datetime.now() - timedelta(days=7)
    async for message in client.iter_messages(group, offset_date=week_ago):
        await message.delete()
    
    # Kick anggota tidak aktif
    async for user in client.iter_participants(group, filter=ChannelParticipantsKicked()):
        await client.kick_participant(group, user)
    
    print("Pembersihan grup selesai.")

    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())