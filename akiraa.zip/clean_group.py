from telethon import TelegramClient
import asyncio
from datetime import datetime, timedelta

async def clean_inactive_members(client, group, days=30):
    participants = await client.get_participants(group)
    now = datetime.now()
    inactive_members = [
        member for member in participants
        if not member.bot and (not member.status.was_online or (now - member.status.was_online) > timedelta(days=days))
    ]
    
    for member in inactive_members:
        try:
            await client.kick_participant(group, member)
            print(f"Menghapus anggota tidak aktif: {member.first_name} {member.last_name}")
        except Exception as e:
            print(f"Gagal menghapus {member.first_name} {member.last_name}: {e}")

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    group = input("Masukkan username atau ID grup: ")
    days = int(input("Hapus anggota yang tidak aktif selama (hari): "))

    await clean_inactive_members(client, group, days)

    await client.disconnect()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))