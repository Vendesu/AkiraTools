from telethon import TelegramClient, events
import json
import asyncio
import os
import traceback
import time
import datetime
import subprocess
import sys

ACCOUNTS_FILE = 'telegram_accounts.json'
REPLIES_FILE = 'auto_replies.json'

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    YELLOW = '\033[93m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║{text.center(width - 2)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_left_aligned_box(title, content, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║ {title.ljust(width - 3)}║")
    print(f"╠{'═' * (width - 2)}╣")
    for line in content:
        print(f"║ {line.ljust(width - 3)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def get_user_choice(max_choice):
    while True:
        try:
            choice = int(input(f"{Colors.CYAN}Pilih opsi (0-{max_choice}): {Colors.ENDC}"))
            if 0 <= choice <= max_choice:
                return choice
            else:
                print(f"{Colors.WARNING}Pilihan tidak valid. Silakan coba lagi.{Colors.ENDC}")
        except ValueError:
            print(f"{Colors.WARNING}Masukan tidak valid. Harap masukkan angka.{Colors.ENDC}")

def load_json_file(filename):
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"{Colors.WARNING}File {filename} tidak ditemukan. Membuat file baru.{Colors.ENDC}")
        return {}
    except json.JSONDecodeError:
        print(f"{Colors.FAIL}Error saat membaca file {filename}. Pastikan formatnya benar.{Colors.ENDC}")
        return {}

def save_json_file(filename, data):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

def manage_replies():
    while True:
        clear_screen()
        print_centered_box("KELOLA AUTO-REPLY", Colors.HEADER)
        options = [
            "1. Tambah Auto-Reply",
            "2. Hapus Auto-Reply",
            "3. Lihat Auto-Reply",
            "0. Kembali ke Menu Utama"
        ]
        print_left_aligned_box("MENU KELOLA AUTO-REPLY", options, Colors.BLUE)
        
        choice = get_user_choice(3)
        
        if choice == 1:
            keyword = input(f"{Colors.CYAN}Masukkan kata kunci: {Colors.ENDC}")
            reply = input(f"{Colors.CYAN}Masukkan balasan: {Colors.ENDC}")
            replies = load_json_file(REPLIES_FILE)
            replies[keyword] = reply
            save_json_file(REPLIES_FILE, replies)
            print(f"{Colors.GREEN}Auto-reply berhasil ditambahkan.{Colors.ENDC}")
        elif choice == 2:
            replies = load_json_file(REPLIES_FILE)
            if not replies:
                print(f"{Colors.WARNING}Tidak ada auto-reply yang tersimpan.{Colors.ENDC}")
            else:
                print(f"{Colors.CYAN}Auto-reply yang tersedia:{Colors.ENDC}")
                for i, (key, value) in enumerate(replies.items(), 1):
                    print(f"{i}. Kata kunci: {key} | Balasan: {value}")
                del_choice = get_user_choice(len(replies))
                if del_choice != 0:
                    key_to_delete = list(replies.keys())[del_choice - 1]
                    del replies[key_to_delete]
                    save_json_file(REPLIES_FILE, replies)
                    print(f"{Colors.GREEN}Auto-reply berhasil dihapus.{Colors.ENDC}")
        elif choice == 3:
            replies = load_json_file(REPLIES_FILE)
            if not replies:
                print(f"{Colors.WARNING}Tidak ada auto-reply yang tersimpan.{Colors.ENDC}")
            else:
                print(f"{Colors.CYAN}Auto-reply yang tersedia:{Colors.ENDC}")
                for key, value in replies.items():
                    print(f"Kata kunci: {key} | Balasan: {value}")
        elif choice == 0:
            break
        
        input(f"\n{Colors.GREEN}Tekan Enter untuk melanjutkan...{Colors.ENDC}")

def loading_animation():
    animation = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    for i in range(20):
        time.sleep(0.1)
        print(f"\r{Colors.BLUE}Memuat {animation[i % len(animation)]}", end="")
    print(f"\r{' ' * 20}\r", end="")

async def run_client(account_name, account_details, replies):
    session_file = f'session_{account_details["phone_number"]}'
    client = TelegramClient(session_file, account_details['api_id'], account_details['api_hash'])
    
    @client.on(events.NewMessage(pattern='(?i).*'))
    async def auto_reply_handler(event):
        if event.is_private:
            message = event.message
            sender = await event.get_sender()
            current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_message = f"{current_time} - From: {sender.id} - Message: {message.raw_text}\n"
            
            with open('pesanlog.txt', 'a', encoding='utf-8') as log_file:
                log_file.write(log_message)
            
            print(f"{Colors.CYAN}Pesan diterima: {message.raw_text}{Colors.ENDC}")
            for key, value in replies.items():
                if key.lower() in message.raw_text.lower():
                    await event.reply(value)
                    print(f"{Colors.GREEN}Membalas pesan: '{message.raw_text}' dengan: '{value}'{Colors.ENDC}")
                    break
    
    try:
        await client.start()
        await client.send_message('me', 'Tes auto-reply')
        await client.run_until_disconnected()
    except Exception as e:
        print(f"{Colors.FAIL}Error saat menjalankan client untuk {account_name}: {str(e)}{Colors.ENDC}")
        traceback.print_exc()
    finally:
        await client.disconnect()

def run_client_in_screen(account_name, account_details, replies):
    script_path = os.path.abspath(__file__)
    screen_name = f"auto_reply_{account_name}"
    
    print_centered_box(f"Auto-Reply untuk {account_name}", Colors.BLUE)
    info = [
        "Menghubungkan akun...",
        "Auto Reply Aktif",
        f"Replies yang dimuat: {len(replies)}"
    ]
    print_left_aligned_box("INFORMASI", info, Colors.CYAN)
    
    temp_account_file = f'temp_account_{account_name}.json'
    temp_replies_file = f'temp_replies_{account_name}.json'
    
    with open(temp_account_file, 'w') as f:
        json.dump(account_details, f)
    
    with open(temp_replies_file, 'w') as f:
        json.dump(replies, f)
    
    command = f"screen -dmS {screen_name} python3 {script_path} run_single_client {account_name} {temp_account_file} {temp_replies_file}"
    
    subprocess.run(command, shell=True)
    
    print(f"{Colors.GREEN}Auto-reply untuk akun {account_name} telah dimulai dalam screen {screen_name}.{Colors.ENDC}")
    print(f"{Colors.YELLOW}Untuk melihat output, gunakan perintah: screen -r {screen_name}{Colors.ENDC}")

def stop_auto_reply():
    clear_screen()
    print_centered_box("HENTIKAN AUTO-REPLY", Colors.HEADER)
    
    result = subprocess.run(['screen', '-ls'], capture_output=True, text=True)
    screens = [line.split('.')[0].strip() for line in result.stdout.split('\n') if 'auto_reply_' in line]
    
    if not screens:
        print(f"{Colors.WARNING}Tidak ada auto-reply yang sedang berjalan.{Colors.ENDC}")
        input(f"\n{Colors.GREEN}Tekan Enter untuk kembali ke menu utama...{Colors.ENDC}")
        return

    print(f"{Colors.CYAN}Auto-reply yang sedang berjalan:{Colors.ENDC}")
    for i, screen in enumerate(screens, 1):
        print(f"{i}. {screen}")
    
    print(f"0. Kembali ke menu utama")
    
    choice = get_user_choice(len(screens))
    
    if choice == 0:
        return
    
    selected_screen = screens[choice - 1]
    
    subprocess.run(['screen', '-S', selected_screen, '-X', 'quit'])
    print(f"{Colors.GREEN}Auto-reply untuk {selected_screen} telah dihentikan.{Colors.ENDC}")
    input(f"\n{Colors.GREEN}Tekan Enter untuk kembali ke menu utama...{Colors.ENDC}")

async def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'run_single_client':
        account_name = sys.argv[2]
        temp_account_file = sys.argv[3]
        temp_replies_file = sys.argv[4]
        
        with open(temp_account_file, 'r') as f:
            account_details = json.load(f)
        
        with open(temp_replies_file, 'r') as f:
            replies = json.load(f)
        
        os.remove(temp_account_file)
        os.remove(temp_replies_file)
        
        await run_client(account_name, account_details, replies)
    else:
        while True:
            clear_screen()
            print_centered_box("AUTO-REPLY SYSTEM", Colors.HEADER)
            options = [
                "1. Jalankan Auto-Reply",
                "2. Kelola Auto-Reply",
                "3. Hentikan Auto-Reply",
                "0. Keluar"
            ]
            print_left_aligned_box("MENU UTAMA", options, Colors.BLUE)
            
            choice = get_user_choice(3)
            
            if choice == 1:
                accounts = load_json_file(ACCOUNTS_FILE)
                if not accounts:
                    print(f"{Colors.FAIL}Tidak ada akun yang tersimpan. Harap tambahkan akun terlebih dahulu.{Colors.ENDC}")
                    input(f"\n{Colors.GREEN}Tekan Enter untuk melanjutkan...{Colors.ENDC}")
                    continue

                print(f"\n{Colors.CYAN}Akun yang tersedia:{Colors.ENDC}")
                for i, (name, details) in enumerate(accounts.items(), 1):
                    print(f"{i}. {name} ({details['phone_number']})")

                account_choice = get_user_choice(len(accounts))
                if account_choice == 0:
                    continue

                account_name = list(accounts.keys())[account_choice - 1]
                account_details = accounts[account_name]

                replies = load_json_file(REPLIES_FILE)
                
                loading_animation()
                run_client_in_screen(account_name, account_details, replies)
                
                input(f"\n{Colors.GREEN}Tekan Enter untuk kembali ke menu utama...{Colors.ENDC}")
            
            elif choice == 2:
                manage_replies()
            
            elif choice == 3:
                stop_auto_reply()
            
            elif choice == 0:
                print(f"{Colors.GREEN}Terima kasih telah menggunakan layanan ini.{Colors.ENDC}")
                break

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"{Colors.FAIL}Terjadi kesalahan: {str(e)}{Colors.ENDC}")
        traceback.print_exc()
