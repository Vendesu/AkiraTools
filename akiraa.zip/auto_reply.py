from telethon import TelegramClient, events
import json
import asyncio

ACCOUNTS_FILE = 'telegram_accounts.json'
REPLIES_FILE = 'auto_replies.json'

def load_accounts():
    try:
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"File {ACCOUNTS_FILE} tidak ditemukan.")
        return {}

def load_replies():
    try:
        with open(REPLIES_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_replies(replies):
    with open(REPLIES_FILE, 'w') as f:
        json.dump(replies, f)

def manage_replies():
    replies = load_replies()
    while True:
        print("\nManajemen Auto-Reply")
        print("1. Tambah Auto-Reply")
        print("2. Hapus Auto-Reply")
        print("3. Lihat Daftar Auto-Reply")
        print("4. Kembali")
        
        choice = input("Pilih menu: ")
        
        if choice == '1':
            keyword = input("Masukkan kata kunci: ").lower()
            response = input("Masukkan balasan: ")
            replies[keyword] = response
            save_replies(replies)
            print("Auto-reply berhasil ditambahkan.")
        elif choice == '2':
            keyword = input("Masukkan kata kunci yang ingin dihapus: ").lower()
            if keyword in replies:
                del replies[keyword]
                save_replies(replies)
                print("Auto-reply berhasil dihapus.")
            else:
                print("Kata kunci tidak ditemukan.")
        elif choice == '3':
            if replies:
                print("Daftar Auto-Reply:")
                for key, value in replies.items():
                    print(f"- '{key}': '{value}'")
            else:
                print("Tidak ada auto-reply yang tersimpan.")
        elif choice == '4':
            break
        else:
            print("Pilihan tidak valid.")
    return replies

async def run_client(account_name, account_details, replies):
    client = TelegramClient(f'session_{account_details["phone_number"]}', account_details['api_id'], account_details['api_hash'])
    
    @client.on(events.NewMessage)
    async def auto_reply_handler(event):
        if hasattr(event, 'raw_text'):
            for key, value in replies.items():
                if key.lower() in event.raw_text.lower():
                    await event.reply(value)
                    break
    
    await client.start()
    print(f"Auto-reply berjalan untuk akun {account_name}...")
    print("Auto Reply Aktif")
    
    # Menjalankan client tanpa menunggu disconnected
    await client.run_until_disconnected()

async def main():
    while True:
        print("\nMenu Utama")
        print("1. Jalankan Auto-Reply")
        print("2. Kelola Auto-Reply")
        print("3. Keluar")
        
        choice = input("Pilih menu: ")
        
        if choice == '1':
            accounts = load_accounts()
            if not accounts:
                print("Tidak ada akun yang tersimpan. Harap tambahkan akun terlebih dahulu.")
                continue

            print("Akun yang tersedia:")
            for name in accounts.keys():
                print(f"- {name}")

            account_name = input("Pilih akun yang akan digunakan untuk auto-reply: ")
            if account_name not in accounts:
                print("Akun tidak ditemukan.")
                continue

            account_details = accounts[account_name]
            replies = load_replies()
            
            # Menjalankan client dalam task terpisah
            client_task = asyncio.create_task(run_client(account_name, account_details, replies))
            
            # Menunggu sebentar untuk memastikan client berjalan
            await asyncio.sleep(5)
            
            # Kembali ke menu utama
            continue
        
        elif choice == '2':
            manage_replies()
        
        elif choice == '3':
            print("Terima kasih telah menggunakan layanan ini.")
            break
        
        else:
            print("Pilihan tidak valid.")

if __name__ == '__main__':
    asyncio.run(main())