from telethon import TelegramClient, events

replies = {
    'halo': 'Hai! Ada yang bisa saya bantu?',
    'terimakasih': 'Sama-sama!',
    'bantuan': 'Silakan hubungi admin untuk bantuan lebih lanjut.'
}

@events.register(events.NewMessage(pattern='(?i).*'))
async def auto_reply(event):
    for key, value in replies.items():
        if key.lower() in event.raw_text.lower():
            await event.reply(value)
            break

async def main():
    client = TelegramClient('session', None, None)
    client.add_event_handler(auto_reply)
    
    await client.start()
    print("Auto-reply berjalan...")
    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())