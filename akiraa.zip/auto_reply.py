from telethon import TelegramClient, events
import asyncio

async def setup_auto_reply(client):
    @client.on(events.NewMessage(incoming=True))
    async def auto_reply(event):
        if event.is_private:  # Hanya merespon pesan pribadi
            await event.reply("Terima kasih atas pesan Anda. Ini adalah balasan otomatis.")

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    await setup_auto_reply(client)
    print("Auto-reply aktif. Tekan Ctrl+C untuk berhenti.")
    await client.run_until_disconnected()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))