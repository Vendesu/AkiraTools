from telethon import TelegramClient

async def main():
    client = TelegramClient('session', None, None)
    await client.start()

    group = await client.get_entity('https://t.me/nama_grup')
    
    active_members = []
    async for user in client.iter_participants(group):
        if user.status and not user.status.was_online:
            active_members.append(user)
    
    print(f"Jumlah anggota aktif: {len(active_members)}")
    for member in active_members:
        print(f"- {member.first_name} {member.last_name if member.last_name else ''}")

    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())