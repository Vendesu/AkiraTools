from telethon import TelegramClient
import json
import csv
import asyncio
import os

ACCOUNTS_FILE = 'telegram_accounts.json'

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def load_groups():
    groups = []
    try:
        with open('grup_id.csv', 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                groups.append((row['Group Name'], int(row['Group ID'])))
    except FileNotFoundError:
        print("File grup_id.csv tidak ditemukan.")
    return groups

async def filter_active_members(client, group_id, group_name):
    try:
        group = await client.get_entity(group_id)
        
        active_members = []
        async for user in client.iter_participants(group):
            if user.status and not user.status.was_online:
                active_members.append(user)
        
        print(f"\nAnggota Aktif Grup: {group_name}")
        print(f"Jumlah anggota aktif: {len(active_members)}")
        for member in active_members:
            print(f"- {member.first_name} {member.last_name if member.last_name else ''}")
    except Exception as e:
        print(f"Gagal mendapatkan anggota aktif untuk grup {group_name}: {str(e)}")

async def main():
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.")
        return

    print("Pilih akun yang akan digunakan:")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = int(input("Masukkan nomor akun: "))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    api_id = account['api_id']
    api_hash = account['api_hash']
    phone_number = account['phone_number']

    client = TelegramClient(f'session_{account_name}', api_id, api_hash)
    await client.start(phone=phone_number)

    groups = load_groups()
    if not groups:
        print("Tidak ada grup yang ditemukan di grup_id.csv")
        return

    print("Daftar Grup:")
    for i, (group_name, _) in enumerate(groups, 1):
        print(f"{i}. {group_name}")

    while True:
        try:
            choice = int(input("\nPilih nomor grup (0 untuk keluar): "))
            if choice == 0:
                break
            if 1 <= choice <= len(groups):
                group_name, group_id = groups[choice - 1]
                await filter_active_members(client, group_id, group_name)
            else:
                print("Pilihan tidak valid.")
        except ValueError:
            print("Masukkan nomor yang valid.")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())