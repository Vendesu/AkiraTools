from telethon import TelegramClient
import json
import csv
import asyncio

def load_credentials():
    try:
        with open('credentials.json', 'r') as f:
            credentials = json.load(f)
        return credentials['api_id'], credentials['api_hash']
    except FileNotFoundError:
        return None, None

def load_groups():
    groups = []
    try:
        with open('grup_id.csv', 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                groups.append((row['Group Name'], int(row['Group ID'])))
    except FileNotFoundError:
        print("File grup_id.csv tidak ditemukan.")
    return groups

async def filter_active_members(client, group_id, group_name):
    try:
        group = await client.get_entity(group_id)
        
        active_members = []
        async for user in client.iter_participants(group):
            if user.status and not user.status.was_online:
                active_members.append(user)
        
        print(f"\nAnggota Aktif Grup: {group_name}")
        print(f"Jumlah anggota aktif: {len(active_members)}")
        for member in active_members:
            print(f"- {member.first_name} {member.last_name if member.last_name else ''}")
    except Exception as e:
        print(f"Gagal mendapatkan anggota aktif untuk grup {group_name}: {str(e)}")

async def main():
    api_id, api_hash = load_credentials()
    if not api_id or not api_hash:
        print("Kredensial tidak ditemukan. Jalankan login.py terlebih dahulu.")
        return

    client = TelegramClient('session', api_id, api_hash)
    await client.start()

    groups = load_groups()
    if not groups:
        print("Tidak ada grup yang ditemukan di grup_id.csv")
        return

    print("Daftar Grup:")
    for i, (group_name, _) in enumerate(groups, 1):
        print(f"{i}. {group_name}")

    while True:
        try:
            choice = int(input("\nPilih nomor grup (0 untuk keluar): "))
            if choice == 0:
                break
            if 1 <= choice <= len(groups):
                group_name, group_id = groups[choice - 1]
                await filter_active_members(client, group_id, group_name)
            else:
                print("Pilihan tidak valid.")
        except ValueError:
            print("Masukkan nomor yang valid.")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())