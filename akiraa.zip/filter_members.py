from telethon import TelegramClient
import asyncio
from datetime import datetime, timedelta

async def filter_active_members(client, group, days=30):
    members = await client.get_participants(group)
    now = datetime.now()
    active_members = [
        member for member in members
        if member.status.was_online and (now - member.status.was_online) <= timedelta(days=days)
    ]
    return active_members

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    group = input("Masukkan username atau ID grup: ")
    days = int(input("Masukkan jumlah hari untuk filter aktivitas: "))

    active_members = await filter_active_members(client, group, days)
    print(f"Jumlah anggota aktif dalam {days} hari terakhir: {len(active_members)}")
    for member in active_members:
        print(f"{member.id}: {member.first_name} {member.last_name}")

    await client.disconnect()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))