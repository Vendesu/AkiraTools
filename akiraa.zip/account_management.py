import json
import os

ACCOUNTS_FILE = 'telegram_accounts.json'

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_accounts(accounts):
    with open(ACCOUNTS_FILE, 'w') as f:
        json.dump(accounts, f)

def add_account():
    accounts = load_accounts()
    account_name = input("Masukkan nama untuk akun baru: ")
    api_id = input("Masukkan API ID: ")
    api_hash = input("Masukkan API Hash: ")
    phone_number = input("Masukkan nomor telepon (format internasional, contoh: +628123456789): ")
    
    accounts[account_name] = {
        "api_id": api_id,
        "api_hash": api_hash,
        "phone_number": phone_number
    }
    
    save_accounts(accounts)
    print(f"Akun {account_name} berhasil ditambahkan.")

def remove_account():
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan.")
        return
    
    print("Akun yang tersedia:")
    for name in accounts.keys():
        print(f"- {name}")
    
    account_name = input("Masukkan nama akun yang ingin dihapus: ")
    if account_name in accounts:
        del accounts[account_name]
        save_accounts(accounts)
        print(f"Akun {account_name} berhasil dihapus.")
    else:
        print("Akun tidak ditemukan.")

def list_accounts():
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan.")
    else:
        print("Daftar akun:")
        for name, details in accounts.items():
            print(f"- {name}: {details['phone_number']}")

def manage_accounts():
    while True:
        print("\nManajemen Akun Telegram")
        print("1. Tambah Akun")
        print("2. Hapus Akun")
        print("3. Lihat Daftar Akun")
        print("4. Kembali ke Menu Utama")
        
        choice = input("Pilih menu: ")
        
        if choice == '1':
            add_account()
        elif choice == '2':
            remove_account()
        elif choice == '3':
            list_accounts()
        elif choice == '4':
            break
        else:
            print("Pilihan tidak valid.")

if __name__ == "__main__":
    manage_accounts()