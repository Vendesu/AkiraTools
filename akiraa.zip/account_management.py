import json
import os

ACCOUNTS_FILE = 'telegram_accounts.json'

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║{text.center(width - 2)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_left_aligned_box(title, content, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║ {title.ljust(width - 3)}║")
    print(f"╠{'═' * (width - 2)}╣")
    for line in content:
        print(f"║ {line.ljust(width - 3)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_accounts(accounts):
    with open(ACCOUNTS_FILE, 'w') as f:
        json.dump(accounts, f)

def add_account():
    accounts = load_accounts()
    account_name = input("Masukkan nama untuk akun baru: ")
    api_id = input("Masukkan API ID: ")
    api_hash = input("Masukkan API Hash: ")
    phone_number = input("Masukkan nomor telepon (format internasional, contoh: +628123456789): ")
    
    accounts[account_name] = {
        "api_id": api_id,
        "api_hash": api_hash,
        "phone_number": phone_number
    }
    
    save_accounts(accounts)
    print(f"{Colors.GREEN}Akun {account_name} berhasil ditambahkan.{Colors.ENDC}")

def remove_account():
    accounts = load_accounts()
    if not accounts:
        print(f"{Colors.WARNING}Tidak ada akun yang tersimpan.{Colors.ENDC}")
        return
    
    print("Akun yang tersedia:")
    for name in accounts.keys():
        print(f"- {name}")
    
    account_name = input("Masukkan nama akun yang ingin dihapus: ")
    if account_name in accounts:
        del accounts[account_name]
        save_accounts(accounts)
        print(f"{Colors.GREEN}Akun {account_name} berhasil dihapus.{Colors.ENDC}")
    else:
        print(f"{Colors.FAIL}Akun tidak ditemukan.{Colors.ENDC}")

def list_accounts():
    accounts = load_accounts()
    if not accounts:
        print(f"{Colors.WARNING}Tidak ada akun yang tersimpan.{Colors.ENDC}")
    else:
        print("Daftar akun:")
        for name, details in accounts.items():
            print(f"- {name}: {details['phone_number']}")

def manage_accounts():
    while True:
        clear_screen()
        print_centered_box("TELEGRAM AUTOMATION TOOL", Colors.HEADER)
        print_centered_box("Created By Akira", Colors.CYAN)
        
        menu_items = [
            "1. Tambah Akun",
            "2. Hapus Akun",
            "3. Lihat Daftar Akun",
            "4. Kembali ke Menu Utama"
        ]
        print_left_aligned_box("MANAJEMEN AKUN TELEGRAM", menu_items, Colors.BLUE)
        
        choice = input(f"{Colors.GREEN}Pilih menu: {Colors.ENDC}")
        
        if choice == '1':
            add_account()
        elif choice == '2':
            remove_account()
        elif choice == '3':
            list_accounts()
        elif choice == '4':
            break
        else:
            print(f"{Colors.FAIL}Pilihan tidak valid.{Colors.ENDC}")
        
        input(f"{Colors.WARNING}Tekan Enter untuk melanjutkan...{Colors.ENDC}")

if __name__ == "__main__":
    manage_accounts()
