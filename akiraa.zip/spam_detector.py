from telethon import TelegramClient, events
from collections import defaultdict
import re

spam_patterns = [
    r'\b(?:buy|sell|discount)\b',
    r'\b(?:limited.offer)\b',
    r'\b(?:click.here)\b',
]

message_count = defaultdict(int)
spam_threshold = 5

@events.register(events.NewMessage)
async def spam_detector(event):
    sender = await event.get_sender()
    message_count[sender.id] += 1
    
    if message_count[sender.id] > spam_threshold:
        for pattern in spam_patterns:
            if re.search(pattern, event.raw_text, re.I):
                await event.delete()
                print(f"Pesan spam terdeteksi dari {sender.first_name}")
                return

async def main():
    client = TelegramClient('session', None, None)
    client.add_event_handler(spam_detector)
    
    await client.start()
    print("Spam detector berjalan...")
    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())