from telethon import TelegramClient, events
import asyncio
import re

spam_patterns = [
    r'\b(jual|beli)\b.*\b(follower|like|view)\b',
    r'\b(gratis|free)\b.*\b(pulsa|kuota)\b',
    r'\b(klik|click)\b.*\b(link|tautan)\b'
]

async def is_spam(message):
    for pattern in spam_patterns:
        if re.search(pattern, message.lower()):
            return True
    return False

async def main(api_id, api_hash, phone):
    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone)

    @client.on(events.NewMessage(pattern='(?i).*'))
    async def spam_detector(event):
        if await is_spam(event.text):
            sender = await event.get_sender()
            print(f"Potensi spam terdeteksi dari {sender.first_name} {sender.last_name}: {event.text}")

    print("Pendeteksi spam sedang berjalan. Tekan Ctrl+C untuk berhenti.")
    await client.run_until_disconnected()

if __name__ == "__main__":
    import sys
    api_id = int(sys.argv[1])
    api_hash = sys.argv[2]
    phone = sys.argv[3]
    asyncio.run(main(api_id, api_hash, phone))