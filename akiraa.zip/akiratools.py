import os
import subprocess
import time
import requests

LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")
LICENSE_URL = "https://raw.githubusercontent.com/Vendesu/ijin/main/licenses.txt"

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    YELLOW = '\033[93m'  # Menambahkan warna YELLOW

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║{text.center(width - 2)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_left_aligned_box(title, content, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║ {title.ljust(width - 3)}║")
    print(f"╠{'═' * (width - 2)}╣")
    for line in content:
        print(f"║ {line.ljust(width - 3)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_menu(current_page=1):
    items_per_page = 5
    all_menu_items = [
        "1. Login Telegram",
        "2. Gabung Grup Otomatis",
        "3. Kirim Pesan Ke Semua Grup",
        "4. Kirim Pesan Ke Semua Anggota",
        "5. Penjadwalan Pesan",
        "6. Filter Anggota Aktif",
        "7. Ekspor Data Anggota",
        "8. Statistik Grup",
        "9. Pendeteksi Spam",
        "10. Backup Chat",
        "11. Auto-Reply",
        "12. Unduh Media",
        "13. Terjemahkan Pesan",
        "14. Pemantau Kata Kunci",
        "15. Pembersihan Grup",
        "16. Keluar"
    ]
    
    start_idx = (current_page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    menu_items = all_menu_items[start_idx:end_idx]
    
    print_left_aligned_box("MENU UTAMA", menu_items, Colors.BLUE)
    
    total_pages = (len(all_menu_items) - 1) // items_per_page + 1
    print(f"{Colors.CYAN}Halaman {current_page}/{total_pages}")
    if current_page < total_pages:
        print(f"{Colors.YELLOW}N. Halaman Berikutnya")
    if current_page > 1:
        print(f"{Colors.YELLOW}P. Halaman Sebelumnya")
    
    return total_pages

def run_script(script_name):
    try:
        subprocess.run(['python', script_name], check=True)
    except subprocess.CalledProcessError as e:
        print(f"{Colors.FAIL}Terjadi kesalahan: {e}{Colors.ENDC}")
    except FileNotFoundError:
        print(f"{Colors.FAIL}File tidak ditemukan.{Colors.ENDC}")
    input(f"{Colors.WARNING}Tekan Enter untuk kembali...{Colors.ENDC}")

def loading_animation():
    animation = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    for i in range(20):
        time.sleep(0.1)
        print(f"\r{Colors.BLUE}Memuat {animation[i % len(animation)]}", end="")
    print(f"\r{' ' * 20}\r", end="")

def check_license(name):
    try:
        response = requests.get(LICENSE_URL)
        if response.status_code == 200:
            licenses = response.text.strip().split('\n')
            for license in licenses:
                license_name, duration = license.split(',')
                if license_name.strip().lower() == name.lower():
                    duration = duration.strip().lower()
                    if duration == "lifetime":
                        return "Lifetime"
                    else:
                        return int(duration)
    except Exception as e:
        print(f"{Colors.FAIL}Error saat memeriksa lisensi: {str(e)}{Colors.ENDC}")
    return None

def get_saved_license():
    try:
        with open(LICENSE_FILE, 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        return None

def main_menu():
    clear_screen()
    print_centered_box("TELEGRAM AUTOMATION TOOL", Colors.HEADER)
    print_centered_box("Created By Akira", Colors.CYAN)
    
    name = get_saved_license()
    if not name:
        print(f"{Colors.FAIL}Lisensi tidak ditemukan. Silakan jalankan installer kembali.{Colors.ENDC}")
        return

    duration = check_license(name)
    
    if duration is None:
        print(f"{Colors.FAIL}Lisensi tidak valid atau telah kadaluarsa. Silakan hubungi admin untuk mendapatkan lisensi baru.{Colors.ENDC}")
        time.sleep(5)
        return
    
    current_page = 1
    total_pages = 1
    
    while True:
        clear_screen()
        print_centered_box("TELEGRAM AUTOMATION TOOL", Colors.HEADER)
        print_centered_box("Created By Akira", Colors.CYAN)
        
        user_info = [
            f"Nama    : {name}",
            f"Lisensi : {'Lifetime' if duration == 'Lifetime' else f'{duration} hari'}"
        ]
        print_left_aligned_box("INFORMASI PENGGUNA", user_info, Colors.CYAN)
        
        total_pages = print_menu(current_page)
        
        warning_text = "PERINGATAN: Resiko ditanggung pengguna.\nAkira tidak menjamin Telegram Anda\nanti-banned"
        print_left_aligned_box("PERINGATAN", warning_text.split('\n'), Colors.RED)
        
        choice = input(f"{Colors.GREEN}Pilih menu: {Colors.ENDC}").upper()
        
        if choice == 'N' and current_page < total_pages:
            current_page += 1
        elif choice == 'P' and current_page > 1:
            current_page -= 1
        elif choice.isdigit() and 1 <= int(choice) <= 15:
            loading_animation()
            scripts = [
                'login.py', 'auto_join.py', 'auto_send_grup.py', 'auto_send_user.py',
                'schedule_message.py', 'filter_members.py', 'export_data.py',
                'group_stats.py', 'spam_detector.py', 'backup_chat.py',
                'auto_reply.py', 'download_media.py', 'message_translator.py',
                'keyword_monitor.py', 'clean_group.py'
            ]
            run_script(scripts[int(choice) - 1])
        elif choice == '16' or choice == 'Q':
            print(f"{Colors.WARNING}Terima kasih telah menggunakan program ini.{Colors.ENDC}")
            break
        else:
            print(f"{Colors.FAIL}Pilihan tidak valid. Silakan coba lagi.{Colors.ENDC}")
            time.sleep(1)

if __name__ == "__main__":
    main_menu()