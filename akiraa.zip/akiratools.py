import os
import subprocess
import time
import requests
import csv
import json
import datetime

LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")
LICENSE_URL = "https://raw.githubusercontent.com/Vendesu/ijin/main/licenses.txt"
ACCOUNTS_FILE = 'telegram_accounts.json'

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    YELLOW = '\033[93m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered_box(text, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║{text.center(width - 2)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_left_aligned_box(title, content, color, width=44):
    print(f"{color}╔{'═' * (width - 2)}╗")
    print(f"║ {title.ljust(width - 3)}║")
    print(f"╠{'═' * (width - 2)}╣")
    for line in content:
        print(f"║ {line.ljust(width - 3)}║")
    print(f"╚{'═' * (width - 2)}╝{Colors.ENDC}")

def print_menu(current_page=1):
    items_per_page = 5
    all_menu_items = [
        "1. Manajemen Akun",
        "2. Login Telegram",
        "3. Gabung Grup Otomatis",
        "4. Kirim Pesan Ke Semua Grup",
        "5. Kirim Pesan Ke Semua Anggota",
        "6. Penjadwalan Pesan",
        "7. Filter Anggota Aktif",
        "8. Statistik Grup",
        "9. Auto-Reply",
        "10. Keluar"
    ]
    
    start_idx = (current_page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    menu_items = all_menu_items[start_idx:end_idx]
    
    print_left_aligned_box("MENU UTAMA", menu_items, Colors.BLUE)
    
    total_pages = (len(all_menu_items) - 1) // items_per_page + 1
    print(f"{Colors.CYAN}Halaman {current_page}/{total_pages}")
    if current_page < total_pages:
        print(f"{Colors.YELLOW}N. Halaman Berikutnya")
    if current_page > 1:
        print(f"{Colors.YELLOW}P. Halaman Sebelumnya")
    
    return total_pages

def run_script(script_name):
    try:
        subprocess.run(['python', script_name], check=True)
    except subprocess.CalledProcessError as e:
        print(f"{Colors.FAIL}Terjadi kesalahan: {e}{Colors.ENDC}")
    except FileNotFoundError:
        print(f"{Colors.FAIL}File tidak ditemukan.{Colors.ENDC}")
    input(f"{Colors.WARNING}Tekan Enter untuk kembali...{Colors.ENDC}")

def loading_animation():
    animation = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    for i in range(20):
        time.sleep(0.1)
        print(f"\r{Colors.BLUE}Memuat {animation[i % len(animation)]}", end="")
    print(f"\r{' ' * 20}\r", end="")

def check_license(name):
    try:
        response = requests.get(LICENSE_URL)
        if response.status_code == 200:
            licenses = response.text.strip().split('\n')
            for license in licenses:
                license_data = license.split(',')
                if len(license_data) == 4:
                    license_name, duration, start_date, end_date = license_data
                    if license_name.strip().lower() == name.lower():
                        # Mengonversi string tanggal ke objek datetime
                        end_date = datetime.datetime.strptime(end_date.strip(), "%Y-%m-%d %H:%M:%S")
                        current_date = datetime.datetime.now()
                        
                        if end_date > current_date:
                            remaining_days = (end_date - current_date).days
                            return remaining_days
                        else:
                            print(f"{Colors.FAIL}Lisensi untuk {name} telah kadaluarsa.{Colors.ENDC}")
                            return None
                else:
                    print(f"{Colors.FAIL}Format lisensi tidak valid: {license}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Error saat memeriksa lisensi: {str(e)}{Colors.ENDC}")
    return None

def get_saved_license():
    try:
        with open(LICENSE_FILE, 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        return None

def get_csv_count(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return sum(1 for line in f) - 1  # Mengurangi 1 untuk header
    except FileNotFoundError:
        return 0

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

def manage_accounts():
    from account_management import manage_accounts
    manage_accounts()

def main_menu():
    clear_screen()
    print_centered_box("TELEGRAM AUTOMATION TOOL", Colors.HEADER)
    print_centered_box("Created By Akira", Colors.CYAN)
    
    name = get_saved_license()
    if not name:
        print(f"{Colors.FAIL}Lisensi tidak ditemukan. Silakan jalankan installer kembali.{Colors.ENDC}")
        return

    duration = check_license(name)
    
    if duration is None:
        print(f"{Colors.FAIL}Lisensi tidak valid atau telah kadaluarsa. Silakan hubungi admin untuk mendapatkan lisensi baru.{Colors.ENDC}")
        time.sleep(5)
        return
    
    current_page = 1
    total_pages = 1
    
    while True:
        clear_screen()
        print_centered_box("TELEGRAM AUTOMATION TOOL", Colors.HEADER)
        print_centered_box("Created By Akira", Colors.CYAN)
        
        total_groups = get_csv_count('grup_id.csv')
        total_members = get_csv_count('user_id.csv')
        
        accounts = load_accounts()
        total_accounts = len(accounts)
        
        user_info = [
            f"Nama    : {name}",
            f"Lisensi : {duration} hari tersisa" if duration is not None else "Lisensi tidak valid",
            f"Total Akun    : {total_accounts}",
            f"Total Grup    : {total_groups}",
            f"Total Anggota : {total_members}"
        ]
        print_left_aligned_box("INFORMASI PENGGUNA", user_info, Colors.CYAN)
        
        total_pages = print_menu(current_page)
        
        warning_text = "PERINGATAN: Resiko ditanggung pengguna.\nAkira tidak menjamin Telegram Anda\nanti-banned"
        print_left_aligned_box("PERINGATAN", warning_text.split('\n'), Colors.RED)
        
        choice = input(f"{Colors.GREEN}Pilih menu: {Colors.ENDC}").upper()
        
        if choice == 'N' and current_page < total_pages:
            current_page += 1
        elif choice == 'P' and current_page > 1:
            current_page -= 1
        elif choice.isdigit() and 1 <= int(choice) <= 9:
            loading_animation()
            if int(choice) == 1:
                manage_accounts()
            else:
                scripts = [
                    'login.py', 'auto_join.py', 'auto_send_grup.py', 'auto_send_user.py',
                    'schedule_message.py', 'filter_members.py', 'group_stats.py',
                    'auto_reply.py'
                ]
                run_script(scripts[int(choice) - 2])
        elif choice == '10' or choice == 'Q':
            print(f"{Colors.WARNING}Terima kasih telah menggunakan program ini.{Colors.ENDC}")
            break
        else:
            print(f"{Colors.FAIL}Pilihan tidak valid. Silakan coba lagi.{Colors.ENDC}")
            time.sleep(1)

if __name__ == "__main__":
    main_menu()