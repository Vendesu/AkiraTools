import os
import time
import requests
import asyncio
from telethon import TelegramClient
from colorama import init, Fore, Back, Style

# Inisialisasi colorama
init(autoreset=True)

LICENSE_FILE = os.path.expanduser("~/.lisensi_otomasi_telegram")
LICENSE_URL = "https://raw.githubusercontent.com/Vendesu/ijin/main/licenses.txt"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    header = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════════╗
║  {Fore.YELLOW + Style.BRIGHT}              TELEGRAM AUTOMATION TOOL              {Fore.CYAN}║
║  {Fore.YELLOW + Style.BRIGHT}                 Created By Akira                   {Fore.CYAN}║
╚══════════════════════════════════════════════════════════╝
    """
    print(header)

def print_menu(current_page=1):
    items_per_page = 5
    all_menu_items = [
        "Login Telegram",
        "Gabung Grup Otomatis",
        "Kirim Pesan Ke Semua Grup",
        "Kirim Pesan Ke Semua Anggota",
        "Penjadwalan Pesan",
        "Filter Anggota Aktif",
        "Ekspor Data Anggota",
        "Statistik Grup",
        "Pendeteksi Spam",
        "Backup Chat",
        "Auto-Reply",
        "Unduh Media",
        "Terjemahkan Pesan",
        "Pemantau Kata Kunci",
        "Pembersihan Grup"
    ]
    
    total_pages = (len(all_menu_items) - 1) // items_per_page + 1
    start_idx = (current_page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    
    menu_items = all_menu_items[start_idx:end_idx]
    
    print(f"{Fore.GREEN}╔══════════════════════════════════════════════════════════╗")
    print(f"{Fore.GREEN}║                        MENU UTAMA                        ║")
    print(f"{Fore.GREEN}╠══════════════════════════════════════════════════════════╣")
    
    for idx, item in enumerate(menu_items, start=start_idx+1):
        print(f"{Fore.GREEN}║ {Fore.YELLOW}{idx:2d}{Fore.GREEN}. {Fore.WHITE}{item:<52}{Fore.GREEN}║")
    
    remaining_slots = items_per_page - len(menu_items)
    for _ in range(remaining_slots):
        print(f"{Fore.GREEN}║                                                          ║")
    
    print(f"{Fore.GREEN}╠══════════════════════════════════════════════════════════╣")
    print(f"{Fore.GREEN}║ {Fore.YELLOW}N{Fore.GREEN}. Halaman Berikutnya   {Fore.YELLOW}P{Fore.GREEN}. Halaman Sebelumnya   {Fore.YELLOW}Q{Fore.GREEN}. Keluar ║")
    print(f"{Fore.GREEN}╚══════════════════════════════════════════════════════════╝")
    print(f"{Fore.CYAN}Halaman {current_page}/{total_pages}")
    
    return total_pages

def print_user_info(name, duration, client_status):
    info = f"""
{Fore.BLUE}╔══════════════════════════════════════════════════════════╗
║  {Fore.WHITE}Nama    : {name:<46}{Fore.BLUE}║
║  {Fore.WHITE}Lisensi : {duration:<46}{Fore.BLUE}║
║  {Fore.WHITE}Status  : {client_status:<46}{Fore.BLUE}║
╚══════════════════════════════════════════════════════════╝
    """
    print(info)

def print_warning():
    warning = f"""
{Fore.RED}╔══════════════════════════════════════════════════════════╗
║             PERINGATAN: Resiko ditanggung pengguna.        ║
║        Akira tidak menjamin Telegram Anda anti-banned      ║
╚══════════════════════════════════════════════════════════╝
    """
    print(warning)

def loading_animation():
    animation = "|/-\\"
    for i in range(20):
        time.sleep(0.1)
        print(f"\r{Fore.CYAN}Loading {animation[i % len(animation)]}", end="")
    print(f"\r{' ' * 20}\r", end="")

def get_saved_license():
    try:
        with open(LICENSE_FILE, 'r') as file:
            return file.read().strip()
    except FileNotFoundError:
        return None

def check_license(name):
    try:
        response = requests.get(LICENSE_URL)
        licenses = response.text.strip().split('\n')
        print(f"DEBUG: Licenses fetched: {licenses}")  # Debug log
        for license in licenses:
            parts = license.split(',')
            print(f"DEBUG: Checking license part: {parts}")  # Debug log
            if len(parts) == 2 and parts[0] == name:
                duration = parts[1].strip()
                if duration.lower() == 'lifetime':
                    return "Lifetime"
                try:
                    days_left = int(duration)
                    return str(max(0, days_left))
                except ValueError:
                    print(f"DEBUG: Invalid duration format: {duration}")  # Debug log
        print(f"DEBUG: License not found for name: {name}")  # Debug log
        return None
    except Exception as e:
        print(f"{Fore.RED}Gagal memeriksa lisensi. Error: {str(e)}")
        return None

def login_telegram():
    api_id = input("Masukkan API ID: ")
    api_hash = input("Masukkan API Hash: ")
    phone = input("Masukkan nomor telepon: ")
    return {'api_id': api_id, 'api_hash': api_hash, 'phone': phone}

async def run_client(client, script_name):
    print(f"Menjalankan {script_name}...")
    # Implementasi untuk menjalankan script
    await asyncio.sleep(2)  # Simulasi menjalankan script
    print(f"{script_name} selesai dijalankan.")
    input("Tekan Enter untuk kembali ke menu utama...")

async def main_menu():
    clear_screen()
    print_header()
    
    name = get_saved_license()
    if not name:
        print(f"{Fore.RED}Lisensi tidak ditemukan. Silakan jalankan installer kembali.")
        return

    duration = check_license(name)
    print(f"DEBUG: Duration returned: {duration}")  # Debug log
    
    if duration is None:
        print(f"{Fore.RED}Lisensi tidak valid atau telah kadaluarsa. Silakan hubungi admin untuk mendapatkan lisensi baru.")
        print(f"DEBUG: Name checked: {name}")  # Debug log
        time.sleep(5)
        return
    
    client = None
    current_page = 1
    
    while True:
        clear_screen()
        print_header()
        
        client_status = 'Logged in' if client else 'Not logged in'
        print_user_info(name, 'Lifetime' if duration == 'Lifetime' else f'{duration} hari', client_status)
        
        total_pages = print_menu(current_page)
        print_warning()
        
        choice = input(f"{Fore.GREEN}Pilih menu (1-15, N, P, atau Q): {Fore.RESET}").upper()
        
        if choice == 'N':
            current_page = min(current_page + 1, total_pages)
        elif choice == 'P':
            current_page = max(current_page - 1, 1)
        elif choice == 'Q':
            if client:
                await client.disconnect()
            print(f"{Fore.YELLOW}Terima kasih telah menggunakan program ini.")
            break
        elif choice.isdigit() and 1 <= int(choice) <= 15:
            if int(choice) == 1:
                loading_animation()
                session = login_telegram()
                client = TelegramClient('session', session['api_id'], session['api_hash'])
                await client.start(session['phone'])
            else:
                if not client:
                    print(f"{Fore.RED}Anda harus login terlebih dahulu. Pilih menu 1 untuk login.")
                    time.sleep(2)
                    continue
                
                loading_animation()
                scripts = [
                    'auto_join.py', 'auto_send_grup.py', 'auto_send_user.py',
                    'schedule_message.py', 'filter_members.py', 'export_data.py',
                    'group_stats.py', 'spam_detector.py', 'backup_chat.py',
                    'auto_reply.py', 'download_media.py', 'message_translator.py',
                    'keyword_monitor.py', 'clean_group.py'
                ]
                await run_client(client, scripts[int(choice) - 2])
        else:
            print(f"{Fore.RED}Pilihan tidak valid. Silakan coba lagi.")
            time.sleep(1)

if __name__ == "__main__":
    asyncio.run(main_menu())