from telethon import TelegramClient
import asyncio
import csv
import json
import os

# Fungsi untuk menyimpan kredensial
def save_credentials(api_id, api_hash):
    credentials = {
        "api_id": api_id,
        "api_hash": api_hash
    }
    with open('credentials.json', 'w') as f:
        json.dump(credentials, f)

# Fungsi untuk memuat kredensial
def load_credentials():
    if os.path.exists('credentials.json'):
        with open('credentials.json', 'r') as f:
            return json.load(f)
    return None

async def get_groups(client):
    regular_groups = []
    topic_groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            group = await client.get_entity(dialog.id)
            if hasattr(group, 'forum') and group.forum:
                topic_groups.append((dialog.id, dialog.name))
                print(f"Grup dengan topik ditemukan: {dialog.name}")
            else:
                regular_groups.append((dialog.id, dialog.name))
    return regular_groups, topic_groups

async def get_members(client, group_id):
    members = []
    async for user in client.iter_participants(group_id):
        members.append((user.id, user.first_name, user.last_name, user.username))
    return members

async def main():
    print("Selamat datang di Telegram Automation Tool")
    
    # Coba memuat kredensial yang tersimpan
    credentials = load_credentials()
    if credentials:
        api_id = credentials['api_id']
        api_hash = credentials['api_hash']
        print("Kredensial ditemukan. Menggunakan API ID dan API Hash yang tersimpan.")
    else:
        print("Silakan masukkan informasi yang diperlukan untuk login:")
        api_id = input("Masukkan API ID: ")
        api_hash = input("Masukkan API Hash: ")
        save_credentials(api_id, api_hash)
        print("Kredensial telah disimpan untuk penggunaan selanjutnya.")

    phone_number = input("Masukkan nomor telepon (format internasional, contoh: +628123456789): ")

    client = TelegramClient('session', api_id, api_hash)
    await client.start(phone=phone_number)

    if await client.is_user_authorized():
        print("Login berhasil!")
        print("Mengambil data grup dan anggota...")

        # Mengambil dan menyimpan ID grup
        regular_groups, topic_groups = await get_groups(client)
        
        with open('grup_id.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Group ID', 'Group Name'])
            writer.writerows(regular_groups)
        print(f"Data {len(regular_groups)} grup reguler telah disimpan ke grup_id.csv")

        with open('topic_grup.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Group ID', 'Group Name'])
            writer.writerows(topic_groups)
        print(f"Data {len(topic_groups)} grup dengan topik telah disimpan ke topic_grup.csv")

        # Mengambil dan menyimpan ID anggota dari semua grup
        all_members = set()
        for group_id, _ in regular_groups + topic_groups:
            members = await get_members(client, group_id)
            all_members.update(members)

        with open('user_id.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['User ID', 'First Name', 'Last Name', 'Username'])
            writer.writerows(all_members)
        print(f"Data {len(all_members)} anggota telah disimpan ke user_id.csv")

        print("Anda sekarang dapat menggunakan fitur-fitur lainnya.")
    else:
        print("Login gagal. Silakan coba lagi.")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())