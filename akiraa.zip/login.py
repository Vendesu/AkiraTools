from telethon import TelegramClient
import asyncio
import csv
import os

async def get_groups(client):
    groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            groups.append((dialog.id, dialog.name))
    return groups

async def get_members(client, group_id):
    members = []
    async for user in client.iter_participants(group_id):
        members.append((user.id, user.first_name, user.last_name, user.username))
    return members

async def main():
    print("Selamat datang di Telegram Automation Tool")
    
    session_file = 'telegram_session'
    
    if os.path.exists(session_file):
        print("Sesi tersimpan ditemukan. Mencoba menggunakan sesi yang ada...")
        client = TelegramClient(session_file, None, None)
        await client.start()
        
        if await client.is_user_authorized():
            print("Sesi masih terhubung. Anda sudah login.")
            print("Anda dapat langsung menggunakan fitur-fitur lainnya.")
            await client.disconnect()
            return
        else:
            print("Sesi tidak valid. Melakukan login ulang...")
            os.remove(session_file)
    
    print("Silakan masukkan informasi yang diperlukan untuk login:")
    api_id = input("Masukkan API ID: ")
    api_hash = input("Masukkan API Hash: ")
    phone_number = input("Masukkan nomor telepon (format internasional, contoh: +628123456789): ")

    client = TelegramClient(session_file, api_id, api_hash)
    await client.start(phone=phone_number)

    if await client.is_user_authorized():
        print("Login berhasil!")
        print("Mengambil data grup dan anggota...")

        # Mengambil dan menyimpan ID grup
        groups = await get_groups(client)
        with open('grup_id.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Group ID', 'Group Name'])
            writer.writerows(groups)
        print(f"Data {len(groups)} grup telah disimpan ke grup_id.csv")

        # Mengambil dan menyimpan ID anggota dari semua grup
        all_members = set()
        for group_id, _ in groups:
            members = await get_members(client, group_id)
            all_members.update(members)

        with open('user_id.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['User ID', 'First Name', 'Last Name', 'Username'])
            writer.writerows(all_members)
        print(f"Data {len(all_members)} anggota telah disimpan ke user_id.csv")

        print("Anda sekarang dapat menggunakan fitur-fitur lainnya.")
        print("Sesi telah disimpan untuk penggunaan berikutnya.")
    else:
        print("Login gagal. Silakan coba lagi.")
        if os.path.exists(session_file):
            os.remove(session_file)
            print("File sesi dihapus. Silakan jalankan script kembali untuk login ulang.")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())