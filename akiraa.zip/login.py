from telethon import TelegramClient
import asyncio
import csv
import json
import os

ACCOUNTS_FILE = 'telegram_accounts.json'

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            return json.load(f)
    return {}

async def get_groups(client):
    groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            groups.append((dialog.id, dialog.name))
    return groups

async def get_members(client, group_id):
    members = []
    async for user in client.iter_participants(group_id):
        members.append((user.id, user.first_name, user.last_name, user.username))
    return members

async def main():
    print("Selamat datang di Telegram Automation Tool")
    
    accounts = load_accounts()
    if not accounts:
        print("Tidak ada akun yang tersimpan. Silakan tambahkan akun terlebih dahulu.")
        return

    print("Pilih akun yang akan digunakan:")
    for i, name in enumerate(accounts.keys(), 1):
        print(f"{i}. {name}")
    
    choice = int(input("Masukkan nomor akun: "))
    account_name = list(accounts.keys())[choice - 1]
    account = accounts[account_name]

    api_id = account['api_id']
    api_hash = account['api_hash']
    phone_number = account['phone_number']

    client = TelegramClient(f'session_{account_name}', api_id, api_hash)
    await client.start(phone=phone_number)

    if await client.is_user_authorized():
        print(f"Login berhasil untuk akun {account_name}!")
        print("Mengambil data grup dan anggota...")

        # Mengambil dan menyimpan ID grup
        groups = await get_groups(client)
        with open('grup_id.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Group ID', 'Group Name'])
            writer.writerows(groups)
        print(f"Data {len(groups)} grup telah disimpan ke grup_id.csv")

        # Mengambil dan menyimpan ID anggota dari semua grup
        all_members = set()
        for group_id, _ in groups:
            members = await get_members(client, group_id)
            all_members.update(members)

        with open('user_id.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['User ID', 'First Name', 'Last Name', 'Username'])
            writer.writerows(all_members)
        print(f"Data {len(all_members)} anggota telah disimpan ke user_id.csv")

        print("Anda sekarang dapat menggunakan fitur-fitur lainnya.")
    else:
        print("Login gagal. Silakan coba lagi.")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())