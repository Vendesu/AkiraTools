import os
import time
from telethon import TelegramClient, events
from telethon.tl.functions.messages import ImportChatInviteRequest, CheckChatInviteRequest

# Dapatkan API ID, hash, dan nomor telepon dari input pengguna
api_id = int(input("Masukkan API ID: "))
api_hash = input("Masukkan API hash: ")
phone = input("Masukkan nomor telepon, termasuk kode negara: ")

# Buat klien Telegram
client = TelegramClient('session', api_id, api_hash)

# Sambungkan ke API Telegram
client.start(phone)

# Fungsi untuk mengotomatiskan join grup dari file grupid.txt
async def join_groups_from_file(filename='group_links.txt'):
    with open(filename, 'r') as f:
        group_invites = [line.strip() for line in f]

    for group_invite in group_invites:
        try:
            hash = await client(CheckChatInviteRequest(group_invite))
            await client(ImportChatInviteRequest(hash))
            print(f"Berhasil bergabung ke grup dengan invite {group_invite}")
        except Exception as e:
            print(f"Gagal bergabung ke grup dengan invite {group_invite}: {e}")
        # Delay 1 menit
        time.sleep(60)

# Jalankan skrip
async def main():
    await join_groups_from_file()

client.loop.run_until_complete(main())
client.disconnect()