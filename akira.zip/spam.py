import os
import time
from telethon import TelegramClient, events
from telethon.tl.types import InputPhoneContact
from telethon.tl.functions.contacts import ImportContactsRequest
from telethon.tl.functions.messages import SendMessageRequest

# Dapatkan API ID, hash, dan nomor telepon dari input pengguna
api_id = int(input("Masukkan API ID: "))
api_hash = input("Masukkan API hash: ")
phone = input("Masukkan nomor telepon, termasuk kode negara: ")

# Buat klien Telegram
client = TelegramClient('session', api_id, api_hash)

# Sambungkan ke API Telegram
client.start(phone)

# Dapatkan daftar grup yang diikuti oleh pengguna
async def get_groups():
    dialogs = await client.get_dialogs()
    groups = [(dialog.title, dialog.id) for dialog in dialogs if dialog.is_group]
    return groups

# Tampilkan daftar grup dan minta pengguna memilih beberapa grup
async def select_groups():
    groups = await get_groups()
    print("Pilih beberapa grup untuk mengumpulkan ID grup:")
    for i, (title, group_id) in enumerate(groups):
        print(f"{i+1}. {title} (ID: {group_id})")
    group_choices = input("Masukkan nomor grup yang dipilih (pisahkan dengan koma): ")
    group_ids = [groups[int(i)-1][1] for i in group_choices.split(',')]
    return group_ids

# Kumpulkan ID grup yang dipilih
async def scrape_group_ids(group_ids):
    group_id_file = 'group_ids.txt'
    with open(group_id_file, 'w') as f:
        for group_id in group_ids:
            f.write(str(group_id) + '\n')

# Kirim pesan ke semua grup dalam file yang dikumpulkan
async def send_message(message):
    group_id_file = 'group_ids.txt'
    with open(group_id_file, 'r') as f:
        group_ids = [int(line.strip()) for line in f] #Perubahan disini

    for group_id in group_ids:
        try:
            await client(SendMessageRequest(
                peer=group_id,
                message=message
            ))
            print(f"Berhasil mengirim pesan ke grup dengan ID: {group_id}")
        except Exception as e:
            print(f"Gagal mengirim pesan ke grup dengan ID {group_id}: {e}")
        # Delay 1 menit
        time.sleep(60)

# Jalankan skrip
async def main():
    group_ids = await select_groups()
    await scrape_group_ids(group_ids)
    message = input("Masukkan pesan yang ingin dikirim: ")
    await send_message(message)

client.loop.run_until_complete(main())
client.disconnect()